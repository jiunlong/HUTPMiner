#include "element.h"
element::element()
{
    seq="";
    utility=0;
}
element::element(string s, double u )
{
    seq=s;
    utility=u;
}

element::~element()
{
    //dtor
}

