#include "event_set.h"

event_set::event_set()
{
    event=0;
    uei=0;
    num_eiv=0;
    max_num_eiv=2;
    //ctor
}

event_set::event_set(int te)
{
    event=te;
    num_eiv=0;
    max_num_eiv=2;
    uei=0;
    //ctor
}

event_set::~event_set()
{
    //dtor
}
