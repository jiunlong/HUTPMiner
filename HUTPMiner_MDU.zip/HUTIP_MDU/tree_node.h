#ifndef TREE_NODE_H
#define TREE_NODE_H
#include <string>
#include "position.h"
//#include "ending_qitem.h"
using namespace std;
//class position;
class tree_node
{
    friend class maxheap;
public:
    tree_node();
    //tree_node(string,double,double,double,double****, position**);
    //int findindex(string item);
    virtual ~tree_node();
    string prefix;
    int seq;
    double swu;
    double maxutility; // utility upper bound of this <treenode.seq>-projected DB
    double *u_in_s;
    double nodeutility;
    //double **ufQ;
    //int ***fitemQ;
    //int ***forderQ;
    //int *num_fQ_in_seq;
    //int *max_num_fQ_in_seq;
    //int **num_fitem_in_Q_in_seq;
    //int **max_num_fitem_in_Q_in_seq;
    int num_items;
    int num_seqs;
    int num_sitems;
    int num_iitems;
    //int length;
    //string *itemset;
    //int *num_items_in_sequence;
    //string **items_in_sequence;
    //int *num_itemsets_in_sequence;
    //double ****smatrix;
    //bool concatenation; //true: i, false: s
    position **pivot;
    int *sid;
    int *iid;
    //ending_qitem *eq_item;
    //tree_node * child;
};

#endif // TREE_NODE_H
