#include <windows.h>
#include <psapi.h>
#include <iostream>
#include <new>
#include <fstream>
#include <string>
#include <cstdlib>
#include <time.h>
//#pragma comment(lib, "strmiids.lib")
//#pragma comment(lib, "psapi.lib")
#include "event_seq.h"
#include "tree_node.h"
#include "HUS.h"
using namespace std;
double utility_threashold=0.2;
double increment=0.009;
int rounds=1;
int num_candidates=0;
int num_peu=1;
int num_elements_in_uchain=0;
int max_num_element_in_ulist=0;
int max_num_element_in_uchain=0;
int num_proj_sequences=0;
int *num_itemsets_in_sequence=0;
int *num_items_in_sequence=0;
int num_items=0;
int max_num_items=130;
int *itemset=new int[max_num_items] {0};
double *utb=new double[max_num_items] {0};
double **endru=0;
double ****smatrix=0;
int **items_in_sequence=0;
double *su=0;
HUS husp;
string fpath="../sipo_data(with translate)/context/";//"../Interval preprocessing/"
string fname="context";//auslan2test translate""
PROCESS_MEMORY_COUNTERS pmc;
double mlimit=9.4;
position *sortpivot(position *t)
{
    position *temp=t;
    int npivot=0;
    while(temp)
    {
        npivot++;
        temp=temp->nxt_pos;
    }
    temp=t;
    position **pivotQ=new position* [npivot]{0};
    for (int i=0;i<npivot;i++)
    {
        pivotQ[i]=temp;
        temp=temp->nxt_pos;
    }
    for (int i=0;i<npivot-1;i++)
    {
        int imin=i;
        for (int j=i+1;j<npivot;j++)
        {
            if (pivotQ[j]->p<pivotQ[imin]->p)
            {
                imin=j;
            }
        }
        if (imin!=i)
        {
            position *te=pivotQ[imin];
            pivotQ[imin]=pivotQ[i];
            pivotQ[i]=te;
        }
    }
    for (int i=0;i<npivot-1;i++)
    {
        pivotQ[i]->nxt_pos=pivotQ[i+1];
    }
    pivotQ[npivot-1]->nxt_pos=0;
    t=pivotQ[0];
    delete [] pivotQ;
    pivotQ=0;
    return t;
}
void copychildnodes(tree_node *qs, tree_node *qd, int n)
{
    //cout<<"copy....................."<<endl;
    for (int i=0; i<n; i++)
    {
        qd[i]=qs[i];
    }
}
void copyQ(int *qs, int *qd, int n)
{
    for (int i=1; i<=n; i++)
    {
        qd[i]=qs[i];
    }
}
void pop_node_from_Q(int *iQ, int *oQ, int n)
{
    //int n=t->num_fitem_in_Q_in_seq[s][no];
    if (!n)
    {
        return;
    }
    int iend=iQ[n];
    int oend=oQ[n];
    n--;
    int i=1,j=2;
    for (; j<=n;)
    {
        if (j<n)
        {
            if (oQ[j]>oQ[j+1])
            {
                j++;
            }
            else if (oQ[j]==oQ[j+1])
            {
                if (iQ[j]>iQ[j+1])
                {
                    j++;
                }
            }

        }
        if (oend<oQ[j])
        {
            break;
        }
        else if (oend==oQ[j])
        {
            if (iend<iQ[j])
            {
                break;
            }
        }
        iQ[i]=iQ[j];
        oQ[i]=oQ[j];
        i=j;
        j*=2;
    }
    iQ[i]=iend;
    oQ[i]=oend;
}

int insert_node_into_Q(int e, int pos, int *iQ, int *oQ, int n)
{

    n++;
    /*
    int *tempiq=new int[n+1] {0};
    int *tempoq=new int[n+1] {0};
    for (int i=1; i<n; i++)
    {
        tempiq[i]=iQ[i];
        tempoq[i]=oQ[i];
    }
    delete [] iQ;
    delete [] oQ;
    iQ=tempiq;
    oQ=tempoq;
    */


    int i=n;
    while (i!=1 && (pos<oQ[i/2] || (pos==oQ[i/2] && e<iQ[i/2])))
    {

        oQ[i]=oQ[i/2];
        iQ[i]=iQ[i/2];
        i/=2;
    }
    oQ[i]=pos;
    iQ[i]=e;
    return n;
    //t->ufQ[s][no]=u;
    //t->num_fitem_in_Q_in_seq[s][no]=n;
    //t->num_fQ_in_seq[t->num_seqs]++;
}

void sort_events_in_a_seq(event_seq *tseq, int sid)
{
    int num_time_points=0;
    int max_num_time_points=tseq[sid].num_e*2;
    double *timepoint_set=new double [max_num_time_points] {0};
    for (int i=0; i<tseq[sid].num_e; i++)
    {
        for (int j=0; j<tseq[sid].e[i].num_eiv; j++)
        {
            bool hitstime=false;
            for (int k=0; k<num_time_points; k++)
            {
                if (timepoint_set[k]==tseq[sid].e[i].uei[j].stime)
                {
                    hitstime=true;
                    break;
                }
            }
            if (!hitstime)
            {
                if (num_time_points==max_num_time_points)
                {
                    max_num_time_points*=2;
                    double *temptimeset=new double [max_num_time_points] {0};
                    for (int k=0; k<num_time_points; k++)
                    {
                        temptimeset[k]=timepoint_set[k];
                    }
                    delete [] timepoint_set;
                    timepoint_set=temptimeset;
                }
                timepoint_set[num_time_points]=tseq[sid].e[i].uei[j].stime;
                num_time_points++;
            }

            bool hitftime=false;
            for (int k=0; k<num_time_points; k++)
            {
                if (timepoint_set[k]==tseq[sid].e[i].uei[j].ftime)
                {
                    hitftime=true;
                    break;
                }
            }
            if (!hitftime)
            {
                if (num_time_points==max_num_time_points)
                {
                    max_num_time_points*=2;
                    double *temptimeset=new double [max_num_time_points] {0};
                    for (int k=0; k<num_time_points; k++)
                    {
                        temptimeset[k]=timepoint_set[k];
                    }
                    delete [] timepoint_set;
                    timepoint_set=temptimeset;
                }
                timepoint_set[num_time_points]=tseq[sid].e[i].uei[j].ftime;
                num_time_points++;
            }
        }

    }
    for (int i=0; i<num_time_points-1; i++)
    {
        int imin=i;
        for (int j=i+1; j<num_time_points; j++)
        {
            if ( timepoint_set[j]< timepoint_set[imin])
            {
                imin=j;
            }
        }
        if (imin!=i)
        {
            double temp=timepoint_set[i];
            timepoint_set[i]=timepoint_set[imin];
            timepoint_set[imin]=temp;
        }
    }
    for (int i=0; i<tseq[sid].num_e-1; i++)
    {
        int imin=i;
        for (int j=i+1; j<tseq[sid].num_e; j++)
        {
            if ( tseq[sid].e[j].event < tseq[sid].e[imin].event)
            {
                imin=j;
            }
        }
        if (imin!=i)
        {
            event_set temp=tseq[sid].e[i];
            tseq[sid].e[i]=tseq[sid].e[imin];
            tseq[sid].e[imin]=temp;
        }
    }
    num_items_in_sequence[sid]=tseq[sid].num_e;
    items_in_sequence[sid]=new int [num_items_in_sequence[sid]] {0};
    for (int i=0; i<num_items_in_sequence[sid]; i++)
    {
        items_in_sequence[sid][i]=tseq[sid].e[i].event;
    }
    num_itemsets_in_sequence[sid]=num_time_points;
    endru[sid]=new double[num_itemsets_in_sequence[sid]] {0};
    smatrix[sid]=new double**[num_items_in_sequence[sid]] {0};
    for (int i=0; i<num_items_in_sequence[sid]; i++)
    {
        smatrix[sid][i]=new double*[num_itemsets_in_sequence[sid]] {0};
        for (int j=0; j<num_itemsets_in_sequence[sid]; j++)
        {
            smatrix[sid][i][j]=new double[5] {0};
        }
    }
    for (int i=0; i<tseq[sid].num_e; i++)
    {
        for (int j=0; j<tseq[sid].e[i].num_eiv; j++)
        {
            for (int k=0; k<num_time_points; k++)
            {
                if (timepoint_set[k]==tseq[sid].e[i].uei[j].stime)
                {
                    smatrix[sid][i][k][0]=tseq[sid].e[i].uei[j].event_u;
                    su[sid]+=tseq[sid].e[i].uei[j].event_u;

                    for (int l=k+1; l<num_time_points; l++)
                    {
                        if (timepoint_set[l]==tseq[sid].e[i].uei[j].ftime)
                        {
                            smatrix[sid][i][k][2]=l;
                            break;
                        }
                    }
                    break;
                }
            }
        }
    }
    for (int k=0; k<num_itemsets_in_sequence[sid]; k++)
    {
        int iuid=0;
        for (int j=num_items_in_sequence[sid]-1; j>=0; j--)
        {
            smatrix[sid][j][k][3]=iuid;
            if (smatrix[sid][j][k][0]>0)
            {
                iuid=j;
            }
        }
    }
    for (int j=0; j<num_items_in_sequence[sid]; j++)
    {
        int suid=0;
        for (int k=num_itemsets_in_sequence[sid]-1; k>=0; k--)
        {
            smatrix[sid][j][k][4]=suid;
            if (smatrix[sid][j][k][0]>0)
            {
                suid=k;
            }
        }
    }
    double curu=su[sid];
    for (int k=0; k<num_itemsets_in_sequence[sid]; k++)
    {
        endru[sid][k]=curu;
        if (smatrix[sid][0][k][0]>0)
        {
            smatrix[sid][0][k][1]=curu;
            curu-=smatrix[sid][0][k][0];
        }
        for (int j=(int) smatrix[sid][0][k][3]; j!=0; )
        {
            smatrix[sid][j][k][1]=curu;
            curu-=smatrix[sid][j][k][0];
            j=(int) smatrix[sid][j][k][3];
        }
    }

    for (int j=0; j<num_items_in_sequence[sid]; j++)
    {

        for (int k=0; k<num_itemsets_in_sequence[sid]; k++)
        {
            if(smatrix[sid][j][k][4]==0)
            {
                break;
            }
            if (smatrix[sid][j][k][0]==0)
            {
                smatrix[sid][j][k][1]=smatrix[sid][j][(int)smatrix[sid][j][k][4]][1];
            }
        }
    }

}
double computeitemutility(int e, double iu)
{
    for (int i=0; i<num_items; i++)
    {
        if (e==itemset[i])
        {
            return utb[i]*iu;
            break;
        }
    }
    return 0;
}

void HUSdfs(tree_node *ptr, bool begin_item)
{
    GetProcessMemoryInfo( GetCurrentProcess(), &pmc, sizeof(pmc));
    if ((double) pmc.PeakWorkingSetSize/(1024*1024*1024)>mlimit)
    {
        cout<<"over the memory limit"<<endl;
        return;
    }
    /*if (ptr->prefix=="[1+")
    {
        cout<<ptr->pivot[0]->num_fitem_in_Q[0];
        char ch;
        cin>>ch;
    }*/
    /*
    if ((ptr->maxutility)<utility_threashold)
    {
        int size_chain=0;
        for (int j=0; j<ptr->num_seqs; j++)
        {
            int size_list=0;
            position *s=ptr->pivot[j];
            while(s)
            {
                position *temp=s;
                //cout<<s->p[0]<<" "<<s->p[1]<<" "<<s->p[2]<<" "<<s->utility<<endl;
                size_list++;
                s=s->nxt_pos;
                delete temp;
            }
            size_chain+=size_list;
            if (size_list>max_num_element_in_ulist)
            {
                max_num_element_in_ulist=size_list;
            }
        }
        if (size_chain>max_num_element_in_uchain)
        {
            max_num_element_in_uchain=size_chain;
        }
        num_elements_in_uchain+=size_chain;
        num_proj_sequences+=ptr->num_seqs;
        delete [] ptr->pivot;
        delete [] ptr->sid;
        delete [] ptr->iid;
        delete [] ptr->maxuats;
        return;
    }
    num_peu++;
    */
    tree_node *tilist=new tree_node [ptr->num_items];
    int max_num_iitems=ptr->num_items;
    tree_node *tslist=new tree_node [ptr->num_items];
    int max_num_sitems=ptr->num_items;
    //cout<<ptr->prefix<<endl;
    /*while (!(ptr->num_seqs))
    {

        cout<<ptr->prefix<<" redi....\n";
        char ch;
        cin>>ch;
    }*/

    if (begin_item)
    {

        for (int i=0; i<ptr->num_seqs; i++)
        {
            double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            //double tmax=ptr->maxuats[i];
            position *t=ptr->pivot[i];

            while (t)
            {
                for (int j=(ptr->iid[i])+1; j>0 && j<num_items_in_sequence[ptr->sid[i]]; )
                {
                    if (smatrix[ptr->sid[i]][j][t->p][0]>0)
                    {
                        if (!(uru_of_first_items[j]))
                        {
                            uru_of_first_items[j]=smatrix[ptr->sid[i]][j][t->p][1];
                        }

                        j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                        /*if (!j)
                        {
                            break;
                        }*/
                    }
                    else if (smatrix[ptr->sid[i]][j][t->p][3])
                    {
                        j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                    }
                    else
                    {
                        break;
                    }
                }
                t=t->nxt_pos;
            }

            for (int j=(ptr->iid[i])+1; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                if (uru_of_first_items[j])
                {
                    bool match_item=false;
                    for (int l=0; l<ptr->num_iitems; l++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==tilist[l].seq)
                        {
                            tilist[l].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                            tilist[l].num_seqs++;
                            //cout<<ptr->seq+","+tilist[l].seq<<endl;
                            match_item=true;
                            break;
                        }
                    }
                    if (!match_item)
                    {
                        if (ptr->num_iitems>=max_num_iitems)
                        {
                            if (max_num_iitems*2>num_items)
                            {
                                max_num_iitems=num_items;
                            }
                            else
                            {
                                max_num_iitems*=2;
                            }
                            tree_node *tempilist=new tree_node [max_num_iitems];
                            copychildnodes(tilist,tempilist,ptr->num_iitems);
                            delete [] tilist;
                            tilist=tempilist;
                        }

                        tilist[ptr->num_iitems].seq=items_in_sequence[ptr->sid[i]][j];
                        tilist[ptr->num_iitems].num_seqs++;
                        //cout<<ptr->seq+","+tilist[ptr->num_iitems].seq<<endl;
                        tilist[ptr->num_iitems].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                        ++(ptr->num_iitems);
                    }
                }
            }
            delete [] uru_of_first_items;
            uru_of_first_items=0;
        }


        for (int i=0; i<ptr->num_seqs; i++)
        {

            double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            //double tmax=ptr->maxuats[i];

            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                position *t=ptr->pivot[i];
                while (t)
                {
                    if (!(uru_of_first_items[j]))
                    {
                        //cout<<"sid: "<<ptr->sid[i]<<" "<<items_in_sequence[ptr->sid[i]][j]<<" "<<t->p<<" "<<t->last_p<<endl;
                        int k=(t->p)+1;
                        //cout<<k<<" "<<t->last_p<<endl;
                        for (; k>(t->p) && k<t->last_p; )
                        {
                            //cout<<k<<endl;
                            if (smatrix[ptr->sid[i]][j][k][0]>0)
                            {
                                if (!(uru_of_first_items[j]))
                                {
                                    uru_of_first_items[j]=smatrix[ptr->sid[i]][j][k][1];
                                    break;
                                }
                                k=(int) smatrix[ptr->sid[i]][j][k][4];
                            }
                            else if (smatrix[ptr->sid[i]][j][k][4]>0)
                            {
                                k=(int) smatrix[ptr->sid[i]][j][k][4];
                            }
                            else
                            {
                                break;
                            }

                        }

                        /*if (uru_of_first_items[j]>0)
                        {
                            break;
                        }*/
                    }
                    else
                    {
                        break;
                    }
                    t=t->nxt_pos;
                }
            }

            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                if (uru_of_first_items[j]>0)
                {
                    bool match_item=false;
                    for (int l=0; l<ptr->num_sitems; l++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==tslist[l].seq)
                        {
                            tslist[l].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                            tslist[l].num_seqs++;
                            //cout<<ptr->seq+","+tslist[l].seq<<endl;
                            match_item=true;
                            break;
                        }
                    }
                    if (!match_item)
                    {
                        if (ptr->num_sitems>=max_num_sitems)
                        {
                            if (max_num_sitems*2>num_items)
                            {
                                max_num_sitems=num_items;
                            }
                            else
                            {
                                max_num_sitems*=2;
                            }
                            tree_node *tempslist=new tree_node [max_num_sitems];
                            copychildnodes(tslist,tempslist,ptr->num_sitems);
                            delete [] tslist;
                            tslist=tempslist;
                        }
                        tslist[ptr->num_sitems].seq=items_in_sequence[ptr->sid[i]][j];
                        //cout<<ptr->seq+","+tslist[ptr->num_sitems].seq<<endl;
                        tslist[ptr->num_sitems].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                        tslist[ptr->num_sitems].num_seqs++;
                        ++(ptr->num_sitems);
                    }
                }
            }
            delete [] uru_of_first_items;
            uru_of_first_items=0;
        }
        /*for (int i=0; i<ptr->num_sitems; i++)
        {
            cout<<ptr->seq<<"]["<<tslist[i].seq<<", #seqs: "<<tslist[i].num_seqs<<endl;
        }*/
        //char charbreak;
        //cin>>charbreak;

        int num_seitems=0;
        tree_node *teslist=new tree_node [ptr->num_items];
        int max_num_seitems=ptr->num_items;
        for (int i=0; i<ptr->num_seqs; i++)
        {
            double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            int *p_of_first_items=new int [num_items_in_sequence[ptr->sid[i]]] {0};
            position *t=ptr->pivot[i];
            while (t)
            {
                for (int qi=0; qi<t->num_oatp; qi++)
                {
                    int j=t->fitemQ[qi][1];
                    if (!(p_of_first_items[j]))
                    {
                        uru_of_first_items[j]=endru[ptr->sid[i]][t->forderQ[qi][1]];
                        p_of_first_items[j]=t->forderQ[qi][1];

                    }
                    else if (p_of_first_items[j]>t->forderQ[qi][1])
                    {
                        uru_of_first_items[j]=endru[ptr->sid[i]][t->forderQ[qi][1]];
                        p_of_first_items[j]=t->forderQ[qi][1];
                    }

                }
                t=t->nxt_pos;
            }
            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                if (p_of_first_items[j])
                {
                    bool match_item=false;
                    for (int l=0; l<num_seitems; l++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==teslist[l].seq)
                        {
                            teslist[l].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                            teslist[l].num_seqs++;
                            //cout<<ptr->seq+","+teslist[l].seq<<endl;
                            match_item=true;
                            break;
                        }
                    }
                    if (!match_item)
                    {
                        if (num_seitems>=max_num_seitems)
                        {
                            if (max_num_seitems*2>num_items)
                            {
                                max_num_seitems=num_items;
                            }
                            else
                            {
                                max_num_seitems*=2;
                            }
                            tree_node *tempslist=new tree_node [max_num_seitems];
                            copychildnodes(teslist,tempslist,num_seitems);
                            delete [] teslist;
                            teslist=tempslist;
                        }
                        teslist[num_seitems].seq=items_in_sequence[ptr->sid[i]][j];
                        teslist[num_seitems].num_seqs++;
                        //cout<<ptr->seq+","+teslist[num_seitems].seq<<endl;
                        teslist[num_seitems].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                        ++(num_seitems);
                    }
                }
            }
            delete [] uru_of_first_items;
            delete [] p_of_first_items;
        }

        tree_node *ilist=0;
        int iitems=0;
        if (ptr->num_iitems)
        {
            ilist=new tree_node[ptr->num_iitems];
            for (int i=0; i<ptr->num_iitems; i++)
            {
                if (tilist[i].swu>=utility_threashold)
                {
                    ilist[iitems]=tilist[i];
                    //cout<<ptr->seq+","+ilist[iitems].seq<<endl;
                    iitems++;
                }
            }
            if (iitems==0)
            {
                delete [] ilist;
                ilist=0;
            }
            ptr->num_iitems=iitems;
        }

        delete [] tilist;
        tilist=0;

        if (ptr->num_iitems>0)
        {

            for (int i=0; i<ptr->num_iitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<ptr->num_iitems; j++)
                {
                    if (ilist[j].seq<ilist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=ilist[i];
                    ilist[i]=ilist[imin];
                    ilist[imin]=temp;
                }
            }
            for (int i=0; i<ptr->num_iitems; i++)
            {
                //cout<<ptr->seq+","+ilist[i].seq<<" "<<ilist[i].swu<<endl;
                ilist[i].num_items=ptr->num_items;
                ilist[i].pivot=new position *[ilist[i].num_seqs] {0};
                ilist[i].sid=new int[ilist[i].num_seqs] {0};
                ilist[i].iid=new int[ilist[i].num_seqs] {0};
                ilist[i].u_in_s=new double [ilist[i].num_seqs] {0};
                ilist[i].num_seqs=0;
            }

            tilist=ilist;

            for (int i=0; i<ptr->num_seqs; i++)
            {
                //double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
                //double tmax=ptr->maxuats[i];
                position **bu=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                //int *nbu=new int [num_items_in_sequence[ptr->sid[i]]]{0};
                position *t=ptr->pivot[i];
                while (t)
                {
                    for (int j=(ptr->iid[i])+1; j>(ptr->iid[i]) && j<num_items_in_sequence[ptr->sid[i]]; )
                    {
                        if (smatrix[ptr->sid[i]][j][t->p][0]>0)
                        {
                            for (int sic=0; sic<ptr->num_iitems; sic++)
                            {
                                if (items_in_sequence[ptr->sid[i]][j]==tilist[sic].seq)
                                {
                                    if (!bu[j])
                                    {
                                        bu[j]=new position(t->p);
                                        for (int is=0; is<t->num_oatp; is++)
                                        {
                                            int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                            int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                            copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                            copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                            int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                            bu[j]->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                            if (t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0]>=tilist[sic].u_in_s[tilist[sic].num_seqs])
                                            {
                                                tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                            }
                                        }
                                        tilist[sic].pivot[tilist[sic].num_seqs]=bu[j];
                                    }
                                    else
                                    {
                                        position *temp=bu[j];
                                        while (temp->nxt_pos)
                                        {
                                            temp=temp->nxt_pos;
                                        }
                                        temp->nxt_pos=new position;
                                        bu[j]=temp=temp->nxt_pos;
                                        for (int is=0; is<t->num_oatp; is++)
                                        {
                                            int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                            int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                            copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                            copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                            int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                            temp->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                            if (temp->mouatp[temp->num_oatp-1]>=tilist[sic].u_in_s[tilist[sic].num_seqs])
                                            {
                                                tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                            }
                                        }
                                    }
                                    break;
                                }
                            }
                            j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                            /*if (!j)
                            {
                                break;
                            }*/
                        }
                        else if (smatrix[ptr->sid[i]][j][t->p][3])
                        {
                            j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                        }
                        else
                        {
                            break;
                        }
                    }
                    t=t->nxt_pos;
                }
                for (int j=(ptr->iid[i])+1; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    if (bu[j])
                    {
                        for (int sic=0; sic<ptr->num_iitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==tilist[sic].seq)
                            {
                                tilist[sic].sid[tilist[sic].num_seqs]=ptr->sid[i];
                                tilist[sic].iid[tilist[sic].num_seqs]=j;
                                //tilist[sic].pivot[tilist[sic].num_seqs]=bu[j];
                                tilist[sic].num_seqs++;
                                break;
                            }
                        }
                    }
                }
                delete [] bu;
                bu=0;
                //delete [] nbu;
            }

            for (int i=0; i<ptr->num_iitems; i++)
            {
                ilist[i].prefix=ptr->prefix+","+to_string(ilist[i].seq)+"+";
                //cout<<ilist[i].seq<<" #seqs: "<<ilist[i].num_seqs<<" "<<ilist[i].swu<<" "<<ilist[i].maxutility<<" "<<ilist[i].nodeutility<<endl;

                HUSdfs(&(ilist[i]), 1);
                //cout<<"818 "<<ilist[i].prefix<<endl;
            }
            /*
            if (ptr->prefix=="[1+")
            {
                cout<<ptr->pivot[0]->num_fitem_in_Q[0];
                char ch;
                cin>>ch;
            }*/
        }

        if (tilist)
        {
            delete [] tilist;
            tilist=0;
        }

        tree_node *slist=0;
        int sitems=0;
        if (ptr->num_sitems>0)
        {
            slist=new tree_node[ptr->num_sitems];
            for (int i=0; i<ptr->num_sitems; i++)
            {
                if (tslist[i].swu>=utility_threashold)
                {
                    slist[sitems]=tslist[i];
                    //cout<<ptr->seq+"]["+slist[sitems].seq<<endl;
                    sitems++;
                }
            }
            if (sitems==0)
            {
                delete [] slist;
                slist=0;
            }
            ptr->num_sitems=sitems;
        }
        delete [] tslist;
        tslist=0;
        if (ptr->num_sitems>0)
        {
            for (int i=0; i<ptr->num_sitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<ptr->num_sitems; j++)
                {
                    if (slist[j].seq<slist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=slist[i];
                    slist[i]=slist[imin];
                    slist[imin]=temp;
                }
            }
            for (int i=0; i<ptr->num_sitems; i++)
            {
                //cout<<ptr->seq<<"]["<<slist[i].seq<<", #seqs: "<<slist[i].num_seqs<<endl;
                slist[i].num_items=ptr->num_items;
                slist[i].pivot=new position *[slist[i].num_seqs] {0};
                slist[i].sid=new int[slist[i].num_seqs] {0};
                slist[i].iid=new int[slist[i].num_seqs] {0};
                slist[i].u_in_s=new double [slist[i].num_seqs] {0};
                slist[i].num_seqs=0;
            }

            tslist=slist;
            //cout<<ptr->num_seqs<<endl;

            for (int i=0; i<ptr->num_seqs; i++)
            {
                //double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
                //double tmax=ptr->maxuats[i];
                position **bu=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    //cout<<"sid: "<<ptr->sid[i]<<", "<<items_in_sequence[ptr->sid[i]][j]<<endl;
                    bool match_item=false;
                    int tempindex=0;
                    for (int sic=0; sic<ptr->num_sitems; sic++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==slist[sic].seq)
                        {
                            match_item=true;
                            tempindex=sic;
                            break;
                        }
                    }
                    //cout<<"735"<<endl;
                    if (match_item)
                    {
                        int sic=tempindex;
                        position *t=ptr->pivot[i];
                        bool has_instances=false;
                        while (t)
                        {
                            int k=(t->p)+1;
                            /*if (t->last_p<1)
                            {
                                cout<<"last_p..."<<endl;
                                char ch;
                                cin>>ch;
                            }*/
                            //cout<<t->p<<" "<<t->last_p<<endl;
                            for (; k>(t->p) && k<t->last_p; )
                            {
                                if (smatrix[ptr->sid[i]][j][k][0]>0)
                                {
                                    //cout<<slist[sic].num_seqs<<endl;
                                    if (!(bu[j]))
                                    {
                                        //cout<<k<<endl;
                                        bu[j]=slist[sic].pivot[slist[sic].num_seqs]=new position;

                                        for (int is=0; is<t->num_oatp; is++)
                                        {
                                            if (k<t->forderQ[is][1])
                                            {
                                                //cout<<k<<endl;
                                                has_instances=true;
                                                int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                slist[sic].pivot[slist[sic].num_seqs]->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                //bu[j]=temp;
                                                if (t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0]>slist[sic].u_in_s[slist[sic].num_seqs])
                                                {
                                                    slist[sic].u_in_s[slist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                }
                                            }
                                        }
                                        if (!has_instances)
                                        {
                                            delete slist[sic].pivot[slist[sic].num_seqs];
                                            bu[j]=slist[sic].pivot[slist[sic].num_seqs]=0;
                                        }
                                    }
                                    else
                                    {
                                        position *temp=bu[j];
                                        while (temp->nxt_pos)
                                        {
                                            temp=temp->nxt_pos;
                                        }
                                        temp->nxt_pos=new position;
                                        temp=temp->nxt_pos;
                                        for (int is=0; is<t->num_oatp; is++)
                                        {
                                            if (k<t->forderQ[is][1])
                                            {
                                                //cout<<k<<endl;
                                                has_instances=true;
                                                int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                temp->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                /*if (n-1==0)
                                                {
                                                    cout<<ptr->prefix<<"]["<<slist[sic].seq<<"+"<<endl;
                                                    cout<<"wt..."<<endl;
                                                    char ch;
                                                    cin>>ch;

                                                }*/
                                                if (temp->mouatp[temp->num_oatp-1]>slist[sic].u_in_s[slist[sic].num_seqs])
                                                {
                                                    slist[sic].u_in_s[slist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                }
                                            }
                                        }
                                        if (has_instances)
                                        {
                                            bu[j]=temp;
                                        }
                                        else
                                        {
                                            delete temp;
                                            if (bu[j]->nxt_pos)
                                            {
                                                bu[j]->nxt_pos=0;
                                            }

                                        }
                                    }
                                    k=(int) smatrix[ptr->sid[i]][j][k][4];
                                }
                                else if (smatrix[ptr->sid[i]][j][k][4]>0)
                                {
                                    k=(int) smatrix[ptr->sid[i]][j][k][4];
                                }
                                else
                                {
                                    break;
                                }
                            }

                            t=t->nxt_pos;
                        }
                        //cout<<"d+!"<<endl;
                        if (has_instances)
                        {
                            slist[sic].sid[slist[sic].num_seqs]=ptr->sid[i];
                            slist[sic].iid[slist[sic].num_seqs]=j;
                            //slist[sic].pivot[slist[sic].num_seqs]=bu[j];
                            (slist[sic].num_seqs)++;
                        }
                    }
                    //cout<<"844"<<endl;
                }


                /*for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    if (bu[j])
                    {
                        for (int sic=0; sic<ptr->num_sitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==slist[sic].seq)
                            {
                                slist[sic].sid[slist[sic].num_seqs]=ptr->sid[i];
                                slist[sic].iid[slist[sic].num_seqs]=j;
                                //slist[sic].pivot[slist[sic].num_seqs]=bu[j];
                                (slist[sic].num_seqs)++;
                                break;
                            }
                        }
                    }
                }*/
                delete [] bu;
                bu=0;

                /*for (int sic=0; sic<ptr->num_sitems; sic++)
                {
                    if (slist[sic].sid[slist[sic].num_seqs-1]==ptr->sid[i])
                    {
                        cout<<"sid: "<<ptr->sid[i]<<endl;
                        cout<<ptr->prefix<<"]["<<slist[sic].seq<<"+"<<endl;
                        char ch;
                        cin>>ch;
                        for (int qq=1; qq<=slist[sic].pivot[slist[sic].num_seqs-1]->num_fitem_in_Q[(slist[sic].pivot[slist[sic].num_seqs-1]->num_oatp)-1]; qq++)
                        {
                            cout<<"("<<items_in_sequence[ptr->sid[i]][slist[sic].pivot[slist[sic].num_seqs-1]->fitemQ[(slist[sic].pivot[slist[sic].num_seqs-1]->num_oatp)-1][qq]]<<", "
                                <<slist[sic].pivot[slist[sic].num_seqs-1]->forderQ[(slist[sic].pivot[slist[sic].num_seqs-1]->num_oatp)-1][qq]<<")";
                        }
                        cout<<endl;
                    }
                }*/

            }


            /*
            for (int i=0; i<ptr->num_sitems; i++)
            {
                if (slist[i].nodeutility>=utility_threashold)
                    husp.insert(element(ptr->prefix+"]["+to_string(slist[i].seq)+"]",slist[i].nodeutility));
            }
            */

            for (int i=0; i<ptr->num_sitems; i++)
            {

                slist[i].prefix=ptr->prefix+"]["+to_string(slist[i].seq)+"+";
                /*cout<<"line: 860 seq: "<<slist[i].prefix<<" #seqs: "<<slist[i].num_seqs<<endl;//<<" "<<slist[i].swu<<" "<<slist[i].maxutility<<" "<<slist[i].nodeutility
                for (int j=0; j<slist[i].num_seqs; j++)
                {
                    position *t=slist[i].pivot[j];
                    while (t)
                    {
                        cout<<"sid: "<<slist[i].sid[j]<<", #oatp: "<<t->num_oatp<<endl;
                        for (int k=0; k<t->num_oatp; k++)
                        {
                            cout<<t->num_fitem_in_Q[k]<<" ";
                            for (int l=1; l<=t->num_fitem_in_Q[k]; l++)
                            {
                                cout<<"("<<items_in_sequence[slist[i].sid[j]][t->fitemQ[k][l]]<<","<<t->forderQ[k][l]<<")";
                            }
                            cout<<" ";
                        }
                        t=t->nxt_pos;
                    }
                }
                cout<<endl;
                //HUSdfs(&(slist[i]), 1);
                cout<<"1005"<<slist[i].prefix<<endl;*/
            }
            for (int i=0; i<ptr->num_sitems; i++)
            {
                HUSdfs(&(slist[i]), 1);
            }
        }

        if (tslist)
        {
            delete [] tslist;
            tslist=0;
        }

        tree_node *eslist=0;
        int seitems=0;
        if (num_seitems>0)
        {
            eslist=new tree_node[num_seitems];
            for (int i=0; i<num_seitems; i++)
            {
                if (teslist[i].swu>=utility_threashold)
                {
                    eslist[seitems]=teslist[i];
                    //cout<<ptr->seq+"]["+eslist[sitems].seq<<endl;
                    seitems++;
                }
            }
            if (seitems==0)
            {
                delete [] eslist;
                eslist=0;
            }
            num_seitems=seitems;
        }
        delete [] teslist;
        teslist=0;

        if (num_seitems>0)
        {
            for (int i=0; i<num_seitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<num_seitems; j++)
                {
                    if (eslist[j].seq<eslist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=eslist[i];
                    eslist[i]=eslist[imin];
                    eslist[imin]=temp;
                }
            }
            //cout<<ptr->prefix<<endl;
            for (int i=0; i<num_seitems; i++)
            {
                //cout<<ptr->prefix<<"]["<<eslist[i].seq<<"-"<<" "<<eslist[i].num_seqs<<endl;
                eslist[i].num_items=ptr->num_items;
                //eslist[i].prefix=ptr->prefix+"]["+to_string(eslist[i].seq)+"-";
                eslist[i].pivot=new position *[eslist[i].num_seqs] {0};
                eslist[i].sid=new int[eslist[i].num_seqs] {0};
                eslist[i].iid=new int[eslist[i].num_seqs] {0};
                eslist[i].u_in_s=new double [eslist[i].num_seqs] {0};
                eslist[i].num_seqs=0;
            }

            teslist=eslist;
            for (int i=0; i<ptr->num_seqs; i++)
            {
                //double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
                //int *p_of_first_items=new int [num_items_in_sequence[ptr->sid[i]]] {0};
                position **bu=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                position *t=ptr->pivot[i];
                //cout<<"1079"<<endl;
                while (t)
                {
                    for (int is=0; is<t->num_oatp; is++)
                    {
                        for (int sic=0; sic<num_seitems; sic++)
                        {
                            if (teslist[sic].seq==items_in_sequence[ptr->sid[i]][t->fitemQ[is][1]])
                            {
                                int j=t->fitemQ[is][1];
                                if (!bu[j])
                                {

                                    bu[j]=new position;
                                    int *iq=new int [1+t->num_fitem_in_Q[is]] {0};
                                    int *oq=new int [1+t->num_fitem_in_Q[is]] {0};
                                    /*cout<<(t->num_fitem_in_Q[is])<<endl;
                                    for (int qqq=1; qqq<=t->num_fitem_in_Q[is]; qqq++)
                                    {
                                        cout<<items_in_sequence[ptr->sid[i]][t->fitemQ[is][qqq]]<<" ";
                                    }*/
                                    copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                    copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                    //int e=t->fitemQ[is][1];

                                    int tp=t->forderQ[is][1];
                                    pop_node_from_Q(iq,oq,t->num_fitem_in_Q[is]);

                                    //int n=insert_node_into_Q(items_in_sequence[ptr->sid[i]][j],(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                    /*if (t->num_fitem_in_Q[is]-1<0)
                                    {
                                        cout<<ptr->prefix<<"]["<<teslist[sic].seq<<"-"<<endl;
                                        cout<<"wt..."<<endl;
                                        char ch;
                                        cin>>ch;

                                    }*/
                                    bu[j]->insert_mouatp(tp,t->mouatp[is],iq,oq,t->num_fitem_in_Q[is]-1);
                                    if (t->mouatp[is]>=teslist[sic].u_in_s[teslist[sic].num_seqs])
                                    {
                                        teslist[sic].u_in_s[teslist[sic].num_seqs]=t->mouatp[is];
                                    }
                                }
                                else
                                {
                                    position *temp=bu[j];
                                    bool found=false;
                                    if (bu[j]->p==t->forderQ[is][1])
                                    {
                                        found=true;
                                    }
                                    if (!found)
                                    {
                                        while (temp->nxt_pos)
                                        {
                                            if (temp->nxt_pos->p==t->forderQ[is][1])
                                            {
                                                found=true;
                                                break;
                                            }
                                            temp=temp->nxt_pos;
                                        }
                                        if (!found)
                                        {
                                            temp->nxt_pos=new position;
                                        }
                                        temp=temp->nxt_pos;
                                    }


                                    int *iq=new int [1+t->num_fitem_in_Q[is]] {0};
                                    int *oq=new int [1+t->num_fitem_in_Q[is]] {0};
                                    copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                    copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                    //int e=t->fitemQ[is][1];
                                    int tp=t->forderQ[is][1];
                                    //int n=insert_node_into_Q(items_in_sequence[ptr->sid[i]][j],(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                    pop_node_from_Q(iq,oq,t->num_fitem_in_Q[is]);
                                    /*if (t->num_fitem_in_Q[is]-1<0)
                                    {
                                        cout<<ptr->prefix<<"]["<<teslist[sic].seq<<"-"<<endl;
                                        cout<<"wt..."<<endl;
                                        char ch;
                                        cin>>ch;

                                    }*/
                                    temp->insert_mouatp(tp,t->mouatp[is],iq,oq,t->num_fitem_in_Q[is]-1);

                                    if (t->mouatp[is]>teslist[sic].u_in_s[teslist[sic].num_seqs])
                                    {
                                        teslist[sic].u_in_s[teslist[sic].num_seqs]=t->mouatp[is];
                                    }
                                }
                                break;

                            }
                        }
                    }
                    t=t->nxt_pos;
                }
                //cout<<"1157 "<<ptr->prefix<<endl;
                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    if (bu[j])
                    {
                        for (int sic=0; sic<num_seitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==teslist[sic].seq)
                            {
                                teslist[sic].sid[teslist[sic].num_seqs]=ptr->sid[i];
                                teslist[sic].iid[teslist[sic].num_seqs]=j;
                                teslist[sic].pivot[teslist[sic].num_seqs]=sortpivot(bu[j]);

                                if (!(bu[j]->num_fitem_in_Q[0]))
                                {
                                    teslist[sic].nodeutility+=teslist[sic].u_in_s[teslist[sic].num_seqs];
                                }
                                teslist[sic].num_seqs++;
                                break;
                            }
                        }
                    }
                }
                delete [] bu;

                //delete [] uru_of_first_items;
                //delete [] p_of_first_items;
            }


            for (int i=0; i<num_seitems; i++)
            {
                eslist[i].prefix=ptr->prefix+"]["+to_string(eslist[i].seq)+"-";
                if (eslist[i].nodeutility && eslist[i].nodeutility>=utility_threashold)
                    husp.insert(element(eslist[i].prefix+"]",eslist[i].nodeutility));
            }

            for (int i=0; i<num_seitems; i++)
            {
                //cout<<eslist[i].seq<<" #seqs: "<<eslist[i].num_seqs<<" "<<eslist[i].swu<<" "<<eslist[i].maxutility<<" "<<eslist[i].nodeutility<<endl;

                HUSdfs(&(eslist[i]), 0);
                //cout<<eslist[i].prefix<<endl;
            }
            /*if (ptr->prefix=="[1+")
            {
                cout<<ptr->pivot[0]->num_fitem_in_Q[0];
                char ch;
                cin>>ch;
            }*/

        }

        if (teslist)
        {
            delete [] teslist;
            teslist=0;
        }

        num_candidates+=ptr->num_iitems+ptr->num_sitems+num_seitems;
        /*if (ptr->prefix=="[1+")
        {
            cout<<ptr->pivot[0]->num_fitem_in_Q[0];
            char ch;
            cin>>ch;
        }*/
    }
    else
    {
        //cout<<"1371"<<endl;
        for (int i=0; i<ptr->num_seqs; i++)
        {
            double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            //double tmax=ptr->maxuats[i];
            position *t=ptr->pivot[i];
            while (t)
            {
                if (endru[ptr->sid[i]][t->p])
                {
                    if (!(t->num_fitem_in_Q[0]))
                    {
                        for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; )
                        {
                            if (smatrix[ptr->sid[i]][j][t->p][0]>0)
                            {
                                if (!(uru_of_first_items[j]))
                                {
                                    uru_of_first_items[j]=smatrix[ptr->sid[i]][j][t->p][1];
                                }

                                j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                                if (!j)
                                {
                                    break;
                                }
                            }
                            else if (smatrix[ptr->sid[i]][j][t->p][3])
                            {
                                j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                            }
                            else
                            {
                                break;
                            }
                        }

                    }
                    else
                    {
                        /*bool is_largest_fe_in_T=false;
                        for (int j=0; j<t->num_oatp; j++)
                        {
                            if(t->p<t->forderQ[j][1])
                            {
                                is_largest_fe_in_T=true;
                                break;
                            }
                        }*/
                        if (t->p<t->last_p)
                        {
                            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; )
                            {
                                if (smatrix[ptr->sid[i]][j][t->p][0]>0)
                                {
                                    if (!(uru_of_first_items[j]))
                                    {
                                        uru_of_first_items[j]=smatrix[ptr->sid[i]][j][t->p][1];
                                    }

                                    j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                                    if (!j)
                                    {
                                        break;
                                    }
                                }
                                else if (smatrix[ptr->sid[i]][j][t->p][3])
                                {
                                    j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }

                }
                t=t->nxt_pos;
            }
            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                if (uru_of_first_items[j])
                {
                    bool match_item=false;
                    for (int l=0; l<ptr->num_iitems; l++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==tilist[l].seq)
                        {
                            tilist[l].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                            tilist[l].num_seqs++;
                            //cout<<ptr->seq+","+tilist[l].seq<<endl;
                            match_item=true;
                            break;
                        }
                    }
                    if (!match_item)
                    {
                        if (ptr->num_iitems>=max_num_iitems)
                        {
                            if (max_num_iitems*2>num_items)
                            {
                                max_num_iitems=num_items;
                            }
                            else
                            {
                                max_num_iitems*=2;
                            }
                            tree_node *tempilist=new tree_node [max_num_iitems];
                            copychildnodes(tilist,tempilist,ptr->num_iitems);
                            delete [] tilist;
                            tilist=tempilist;
                        }
                        tilist[ptr->num_iitems].seq=items_in_sequence[ptr->sid[i]][j];
                        tilist[ptr->num_iitems].num_seqs++;
                        //cout<<ptr->seq+","+tilist[ptr->num_iitems].seq<<endl;
                        tilist[ptr->num_iitems].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                        ++(ptr->num_iitems);
                    }
                }
            }
            delete [] uru_of_first_items;
        }
//cout<<"1485"<<endl;

        for (int i=0; i<ptr->num_seqs; i++)
        {
            double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            //double tmax=ptr->maxuats[i];
            position *t=ptr->pivot[i];
            if (!(t->num_fitem_in_Q[0]))
            {
                int k=t->p;
                /*while (t)
                {
                    if (t->p<k)
                    {
                        k=t->p;
                        cout<<"1500 wtf..............\n";
                        char cbreak;
                        cin>>cbreak;
                    }
                    t=t->nxt_pos;
                }*/
                k++;
                if (k<num_itemsets_in_sequence[ptr->sid[i]])
                {
                    if (endru[ptr->sid[i]][k])
                    {
                        for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                        {
                            uru_of_first_items[j]=smatrix[ptr->sid[i]][j][k][1];
                        }
                    }
                }
            }
            else
            {
                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    t=ptr->pivot[i];
                    while (t)
                    {
                        int k=(t->p)+1;
                        if (endru[ptr->sid[i]][k])
                        {
                            int lastitemset=t->last_p;
                            /*for (int is=0; is<t->num_oatp; is++)
                            {
                                if (t->p<t->forderQ[is][1])
                                {
                                    if (t->forderQ[is][1]>lastitemset)
                                    {
                                        lastitemset=t->forderQ[is][1];
                                    }
                                }
                            }*/
                            for (; k>t->p && k<lastitemset; )
                            {
                                if (smatrix[ptr->sid[i]][j][k][0]>0)
                                {
                                    if (uru_of_first_items[j]<smatrix[ptr->sid[i]][j][k][1])
                                    {
                                        uru_of_first_items[j]=smatrix[ptr->sid[i]][j][k][1];
                                        break;
                                    }
                                    k=(int) smatrix[ptr->sid[i]][j][k][4];
                                    if (!k)
                                    {
                                        break;
                                    }
                                }
                                else if (smatrix[ptr->sid[i]][j][k][4])
                                {
                                    k=(int) smatrix[ptr->sid[i]][j][k][4];
                                }
                                else
                                {
                                    break;
                                }
                            }

                        }
                        //int lastitemset=t->last_p;
                        /*if (uru_of_first_items[j])//|| !(smatrix[ptr->sid[i]][j][lastitemset-1][4])
                        {
                            break;
                        }*/
                        t=t->nxt_pos;
                    }
                }
            }

//cout<<"1569"<<endl;
            //cout<<"1410"<<endl;
            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                if (uru_of_first_items[j])
                {
                    bool match_item=false;
                    for (int l=0; l<ptr->num_sitems; l++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==tslist[l].seq)
                        {
                            tslist[l].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                            tslist[l].num_seqs++;
                            //cout<<ptr->seq+","+tslist[l].seq<<endl;
                            match_item=true;
                            break;
                        }
                    }
                    if (!match_item)
                    {
                        if (ptr->num_sitems>=max_num_sitems)
                        {
                            if (max_num_sitems*2>num_items)
                            {
                                max_num_sitems=num_items;
                            }
                            else
                            {
                                max_num_sitems*=2;
                            }
                            tree_node *tempslist=new tree_node [max_num_sitems];
                            copychildnodes(tslist,tempslist,ptr->num_sitems);
                            delete [] tslist;
                            tslist=tempslist;
                        }
                        tslist[ptr->num_sitems].seq=items_in_sequence[ptr->sid[i]][j];
                        tslist[ptr->num_sitems].num_seqs++;
                        //cout<<ptr->seq+","+tslist[ptr->num_sitems].seq<<endl;
                        tslist[ptr->num_sitems].swu+=ptr->u_in_s[i]+uru_of_first_items[j];
                        ++(ptr->num_sitems);
                    }
                }
            }
            delete [] uru_of_first_items;
        }

        //cout<<"1614"<<endl;
        int num_ieitems=0;
        int num_seitems=0;
        tree_node *teilist=new tree_node [ptr->num_items];
        tree_node *teslist=new tree_node [ptr->num_items];
        int max_num_ieitems=ptr->num_items;
        int max_num_seitems=ptr->num_items;

        for (int i=0; i<ptr->num_seqs; i++)
        {
            double *uru_of_first_eiitems=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            int *p_of_first_eiitems=new int [num_items_in_sequence[ptr->sid[i]]] {0};
            double *uru_of_first_esitems=new double [num_items_in_sequence[ptr->sid[i]]] {0};
            int *p_of_first_esitems=new int [num_items_in_sequence[ptr->sid[i]]] {0};
            position *t=ptr->pivot[i];
            while (t)
            {
                for (int ie=0; ie<t->num_oatp; ie++)
                {
                    if (t->num_fitem_in_Q[ie])
                    {
                        int j=t->fitemQ[ie][1];
                        if (t->forderQ[ie][1]==t->p)
                        {
                            if (!uru_of_first_eiitems[j])
                            {
                                uru_of_first_eiitems[j]=endru[ptr->sid[i]][t->forderQ[ie][1]];
                                p_of_first_eiitems[j]=t->forderQ[ie][1];
                            }
                            else if (p_of_first_eiitems[j]>t->forderQ[ie][1])
                            {
                                uru_of_first_eiitems[j]=endru[ptr->sid[i]][t->forderQ[ie][1]];
                                p_of_first_eiitems[j]=t->forderQ[ie][1];
                            }
                        }
                        else if (t->forderQ[ie][1]>t->p)
                        {
                            if (!uru_of_first_esitems[j])
                            {
                                uru_of_first_esitems[j]=endru[ptr->sid[i]][t->forderQ[ie][1]];
                                p_of_first_esitems[j]=t->forderQ[ie][1];
                            }
                            else if (p_of_first_esitems[j]>t->forderQ[ie][1])
                            {
                                uru_of_first_esitems[j]=endru[ptr->sid[i]][t->forderQ[ie][1]];
                                p_of_first_esitems[j]=t->forderQ[ie][1];
                            }
                        }

                    }
                }
                t=t->nxt_pos;
            }
            for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
            {
                if (p_of_first_eiitems[j])
                {
                    bool found=false;
                    for (int ie=0; ie<num_ieitems; ie++)
                    {
                        if (teilist[ie].seq==items_in_sequence[ptr->sid[i]][j])
                        {
                            teilist[ie].swu+=ptr->u_in_s[i]+uru_of_first_eiitems[j];
                            teilist[ie].num_seqs++;
                            found=true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        if (num_ieitems>=max_num_ieitems)
                        {
                            if (max_num_ieitems*2>num_items)
                            {
                                max_num_ieitems=num_items;
                            }
                            else
                            {
                                max_num_ieitems*=2;
                            }
                            tree_node *tempslist=new tree_node [max_num_ieitems];
                            copychildnodes(teilist,tempslist,num_ieitems);
                            delete [] teilist;
                            teilist=tempslist;
                        }
                        teilist[num_ieitems].seq=items_in_sequence[ptr->sid[i]][j];
                        teilist[num_ieitems].swu+=ptr->u_in_s[i]+uru_of_first_eiitems[j];
                        teilist[num_ieitems].num_seqs++;
                        num_ieitems++;
                    }
                }
                if (p_of_first_esitems[j])
                {
                    bool found=false;
                    for (int ie=0; ie<num_seitems; ie++)
                    {
                        if (teslist[ie].seq==items_in_sequence[ptr->sid[i]][j])
                        {
                            teslist[ie].swu+=ptr->u_in_s[i]+uru_of_first_esitems[j];
                            teslist[ie].num_seqs++;
                            found=true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        if (num_seitems>=max_num_seitems)
                        {
                            if (max_num_seitems*2>num_items)
                            {
                                max_num_seitems=num_items;
                            }
                            else
                            {
                                max_num_seitems*=2;
                            }
                            tree_node *tempslist=new tree_node [max_num_seitems];
                            copychildnodes(teslist,tempslist,num_seitems);
                            delete [] teslist;
                            teslist=tempslist;
                        }
                        teslist[num_seitems].seq=items_in_sequence[ptr->sid[i]][j];
                        teslist[num_seitems].swu+=ptr->u_in_s[i]+uru_of_first_esitems[j];
                        teslist[num_seitems].num_seqs++;
                        num_seitems++;
                    }
                }
            }
            delete [] uru_of_first_eiitems;
            delete [] uru_of_first_esitems;
            delete [] p_of_first_eiitems;
            delete [] p_of_first_esitems;
        }
        //cout<<"1747"<<endl;
        tree_node *ilist=0;
        int iitems=0;
        if (ptr->num_iitems)
        {
            ilist=new tree_node[ptr->num_iitems];
            for (int i=0; i<ptr->num_iitems; i++)
            {
                if (tilist[i].swu>=utility_threashold)
                {
                    ilist[iitems]=tilist[i];
                    //cout<<ptr->seq+","+ilist[iitems].seq<<endl;
                    iitems++;
                }
            }
            if (iitems==0)
            {
                delete [] ilist;
                ilist=0;
            }
            ptr->num_iitems=iitems;
        }

        delete [] tilist;
        tilist=0;
        if (ptr->num_iitems>0)
        {
            for (int i=0; i<ptr->num_iitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<ptr->num_iitems; j++)
                {
                    if (ilist[j].seq<ilist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=ilist[i];
                    ilist[i]=ilist[imin];
                    ilist[imin]=temp;
                }
            }

            for (int i=0; i<ptr->num_iitems; i++)
            {
                //cout<<ptr->prefix<<","<<ilist[i].seq<<" "<<ilist[i].num_seqs<<endl;

                ilist[i].num_items=ptr->num_items;
                ilist[i].pivot=new position *[ilist[i].num_seqs] {0};
                ilist[i].sid=new int[ilist[i].num_seqs] {0};
                ilist[i].iid=new int[ilist[i].num_seqs] {0};
                ilist[i].u_in_s=new double [ilist[i].num_seqs] {0};
                ilist[i].num_seqs=0;
            }
            tilist=ilist;
            //cout<<"1804"<<endl;
            for (int i=0; i<ptr->num_seqs; i++)
            {
                position **bu=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                //double tmax=ptr->maxuats[i];
                position *t=ptr->pivot[i];
                while (t)
                {
                    if (endru[ptr->sid[i]][t->p])
                    {
                        for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; )
                        {
                            if (smatrix[ptr->sid[i]][j][t->p][0]>0)
                            {
                                for (int sic=0; sic<ptr->num_iitems; sic++)
                                {
                                    if (items_in_sequence[ptr->sid[i]][j]==tilist[sic].seq)
                                    {
                                        if (!bu[j])
                                        {
                                            bu[j]=new position(t->p);
                                            for (int is=0; is<t->num_oatp; is++)
                                            {
                                                if (t->num_fitem_in_Q[is])
                                                {
                                                    if (t->p<t->forderQ[is][1])
                                                    {
                                                        int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                        copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                        int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                                        bu[j]->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                                        if (t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0]>tilist[sic].u_in_s[tilist[sic].num_seqs])
                                                        {
                                                            tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                                        }
                                                    }

                                                }
                                                else
                                                {

                                                    int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                    int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                    //copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                    //copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                    int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                                    bu[j]->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                                    if (t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0]>tilist[sic].u_in_s[tilist[sic].num_seqs])
                                                    {
                                                        tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                                    }
                                                }
                                            }
                                            if (!(bu[j]->num_oatp))
                                            {
                                                delete bu[j];
                                                bu[j]=0;
                                            }
                                        }
                                        else
                                        {
                                            position *temp=bu[j];
                                            while (temp->nxt_pos)
                                            {
                                                temp=temp->nxt_pos;
                                            }

                                            temp->nxt_pos=new position;
                                            //temp=temp->nxt_pos;
                                            for (int is=0; is<t->num_oatp; is++)
                                            {
                                                if (t->num_fitem_in_Q[is])
                                                {
                                                    if (t->p<t->forderQ[is][1])
                                                    {
                                                        int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                        copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                        int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                                        temp->nxt_pos->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                                        if (t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0]>tilist[sic].u_in_s[tilist[sic].num_seqs])
                                                        {
                                                            tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                                        }
                                                    }

                                                }
                                                else
                                                {
                                                    int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                    int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                    //copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                    //copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                    int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                                    temp->nxt_pos->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                                    if (t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0]>=tilist[sic].u_in_s[tilist[sic].num_seqs])
                                                    {
                                                        tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                                    }
                                                }

                                                /*
                                                if (t->p<t->forderQ[is][1])
                                                {
                                                    int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                    int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                    copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                    copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                    int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][t->p][2],iq,oq, t->num_fitem_in_Q[is]);
                                                    temp->nxt_pos->insert_mouatp(t->p,t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0],iq,oq,n);
                                                    if (temp->nxt_pos->mouatp[temp->nxt_pos->num_oatp-1]>=tilist[sic].u_in_s[tilist[sic].num_seqs])
                                                    {
                                                        tilist[sic].u_in_s[tilist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][t->p][0];
                                                    }
                                                }
                                                */
                                            }
                                            if (!(temp->nxt_pos->num_oatp))
                                            {
                                                delete temp->nxt_pos;
                                                temp->nxt_pos=0;
                                            }

                                        }

                                        break;
                                    }
                                }
                                j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                                if (!j)
                                {
                                    break;
                                }
                            }
                            else if (smatrix[ptr->sid[i]][j][t->p][3])
                            {
                                j=(int) smatrix[ptr->sid[i]][j][t->p][3];
                            }
                            else
                            {
                                break;
                            }
                        }

                    }

                    t=t->nxt_pos;
                }
                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    if (bu[j])
                    {
                        for (int sic=0; sic<ptr->num_iitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==tilist[sic].seq)
                            {
                                tilist[sic].sid[tilist[sic].num_seqs]=ptr->sid[i];
                                tilist[sic].iid[tilist[sic].num_seqs]=j;
                                tilist[sic].pivot[tilist[sic].num_seqs]=bu[j];
                                tilist[sic].num_seqs++;
                                break;
                            }
                        }
                    }

                }
                delete [] bu;
            }
            //cout<<"1972"<<endl;

            for (int i=0; i<ptr->num_iitems; i++)
            {
                ilist[i].prefix=ptr->prefix+","+to_string(ilist[i].seq)+"+";
                //cout<<ilist[i].seq<<" #seqs: "<<ilist[i].num_seqs<<" "<<ilist[i].swu<<" "<<ilist[i].maxutility<<" "<<ilist[i].nodeutility<<endl;

                HUSdfs(&(ilist[i]), 1);
            }
            /*if (ptr->prefix=="[1+")
            {
                cout<<ptr->pivot[0]->num_fitem_in_Q[0];
                char ch;
                cin>>ch;
            }*/
        }

        if (tilist)
        {
            delete [] tilist;
        }
        //cout<<"1993"<<endl;
        tree_node *slist=0;
        int sitems=0;
        if (ptr->num_sitems>0)
        {
            slist=new tree_node[ptr->num_sitems];
            for (int i=0; i<ptr->num_sitems; i++)
            {
                if (tslist[i].swu>=utility_threashold)
                {
                    slist[sitems]=tslist[i];
                    //cout<<ptr->seq+"]["+slist[sitems].seq<<endl;
                    sitems++;
                }
            }
            if (sitems==0)
            {
                delete [] slist;
                slist=0;
            }
            ptr->num_sitems=sitems;
        }
        delete [] tslist;
        tslist=0;
        if (ptr->num_sitems>0)
        {
            for (int i=0; i<ptr->num_sitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<ptr->num_sitems; j++)
                {
                    if (slist[j].seq<slist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=slist[i];
                    slist[i]=slist[imin];
                    slist[imin]=temp;
                }
            }
            for (int i=0; i<ptr->num_sitems; i++)
            {
                //cout<<ptr->seq+"]["+slist[i].seq<<" "<<slist[i].swu<<endl;
                slist[i].num_items=ptr->num_items;
                slist[i].pivot=new position *[slist[i].num_seqs] {0};
                slist[i].sid=new int[slist[i].num_seqs] {0};
                slist[i].iid=new int[slist[i].num_seqs] {0};
                slist[i].u_in_s=new double [slist[i].num_seqs] {0};
                slist[i].num_seqs=0;
            }

            tslist=slist;

            for (int i=0; i<ptr->num_seqs; i++)
            {
                //double *uru_of_first_items=new double [num_items_in_sequence[ptr->sid[i]]] {0};
                //double tmax=ptr->maxuats[i];
                position **bu=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    for (int sic=0; sic<ptr->num_sitems; sic++)
                    {
                        if (items_in_sequence[ptr->sid[i]][j]==tslist[sic].seq)
                        {
                            position *t=ptr->pivot[i];
                            int lastitemset=num_itemsets_in_sequence[ptr->sid[i]];
                            position *temp=bu[j];
                            if (!(t->num_fitem_in_Q[0]))
                            {
                                for (int k=(ptr->pivot[i]->p)+1; k>(ptr->pivot[i]->p) && k<num_itemsets_in_sequence[ptr->sid[i]];)
                                {
                                    if (smatrix[ptr->sid[i]][j][k][0]>0)
                                    {
                                        while (t)
                                        {
                                            if (t->p<k)
                                            {
                                                if (!bu[j])
                                                {
                                                    bu[j]=new position;
                                                    for (int is=0; is<t->num_oatp; is++)
                                                    {
                                                        int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        //copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                        //copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                        int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                        bu[j]->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                        if (t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0]>tslist[sic].u_in_s[tslist[sic].num_seqs])
                                                        {
                                                            tslist[sic].u_in_s[tslist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                        }


                                                    }
                                                    if (!(bu[j]->num_oatp))
                                                    {
                                                        delete bu[j];
                                                        bu[j]=0;
                                                    }
                                                    else
                                                    {
                                                        temp=bu[j];
                                                    }

                                                }
                                                else
                                                {

                                                    /*while (temp->nxt_pos)
                                                    {
                                                        temp=temp->nxt_pos;
                                                    }*/
                                                    temp->nxt_pos=new position;
                                                    //temp=temp->nxt_pos;
                                                    for (int is=0; is<t->num_oatp; is++)
                                                    {
                                                        int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                        //copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                        //copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                        int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                        temp->nxt_pos->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                        if (t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0]>=tslist[sic].u_in_s[tslist[sic].num_seqs])
                                                        {
                                                            tslist[sic].u_in_s[tslist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                        }

                                                    }
                                                    if (!(temp->nxt_pos->num_oatp))
                                                    {
                                                        delete temp->nxt_pos;
                                                        temp->nxt_pos=0;
                                                    }
                                                    else
                                                    {
                                                        temp=temp->nxt_pos;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                break;
                                            }
                                            t=t->nxt_pos;
                                        }

                                        k=(int) smatrix[ptr->sid[i]][j][k][4];
                                    }
                                    else if (smatrix[ptr->sid[i]][j][k][4]>0)
                                    {
                                        k=(int) smatrix[ptr->sid[i]][j][k][4];
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                            else
                            {
                                while (t)
                                {
                                    int k=(t->p)+1;
                                    //int lastitemset=num_itemsets_in_sequence[ptr->sid[i]];
                                    if (t->num_fitem_in_Q[0])
                                    {
                                        lastitemset=t->last_p;
                                    }
                                    if (endru[ptr->sid[i]][k])
                                    {
                                        for (; k>t->p && k<lastitemset; )
                                        {
                                            if (smatrix[ptr->sid[i]][j][k][0]>0)
                                            {
                                                if (!bu[j])
                                                {
                                                    bu[j]=new position;
                                                    for (int is=0; is<t->num_oatp; is++)
                                                    {
                                                        if (t->num_fitem_in_Q[is])
                                                        {
                                                            if (k<t->forderQ[is][1])
                                                            {
                                                                int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                                int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                                copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                                copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                                int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                                bu[j]->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                                if (t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0]>tslist[sic].u_in_s[tslist[sic].num_seqs])
                                                                {
                                                                    tslist[sic].u_in_s[tslist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                                }
                                                            }
                                                        }
                                                    }
                                                    if (!(bu[j]->num_oatp))
                                                    {
                                                        delete bu[j];
                                                        bu[j]=0;
                                                    }

                                                }
                                                else
                                                {
                                                    position *temp=bu[j];
                                                    position *rear=temp;
                                                    while (temp)
                                                    {
                                                        rear=temp;
                                                        if (temp->p==k)
                                                        {
                                                            break;
                                                        }
                                                        temp=temp->nxt_pos;
                                                    }
                                                    if (!temp)
                                                    {
                                                        temp=rear;
                                                        temp->nxt_pos=new position;
                                                        for (int is=0; is<t->num_oatp; is++)
                                                        {
                                                            if (t->num_fitem_in_Q[is])
                                                            {
                                                                if (k<t->forderQ[is][1])
                                                                {
                                                                    int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                                    int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                                    copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                                    copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                                    int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                                    temp->nxt_pos->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                                    if (t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0]>=tslist[sic].u_in_s[tslist[sic].num_seqs])
                                                                    {
                                                                        tslist[sic].u_in_s[tslist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                                    }
                                                                }
                                                            }

                                                        }
                                                        if (!(temp->nxt_pos->num_oatp))
                                                        {
                                                            delete temp->nxt_pos;
                                                            temp->nxt_pos=0;
                                                        }


                                                    }
                                                    else
                                                    {
                                                        for (int is=0; is<t->num_oatp; is++)
                                                        {
                                                            if (t->num_fitem_in_Q[is])
                                                            {
                                                                if (k<t->forderQ[is][1])
                                                                {
                                                                    int *iq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                                    int *oq=new int [2+t->num_fitem_in_Q[is]] {0};
                                                                    copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                                                    copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                                                    int n=insert_node_into_Q(j,(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                                                    temp->insert_mouatp(k,t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0],iq,oq,n);
                                                                    if (t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0]>=tslist[sic].u_in_s[tslist[sic].num_seqs])
                                                                    {
                                                                        tslist[sic].u_in_s[tslist[sic].num_seqs]=t->mouatp[is]+smatrix[ptr->sid[i]][j][k][0];
                                                                    }
                                                                }
                                                            }

                                                        }
                                                    }

                                                    //temp=temp->nxt_pos;

                                                }

                                                k=(int) smatrix[ptr->sid[i]][j][k][4];
                                                if (!k)
                                                {
                                                    break;
                                                }
                                            }
                                            else if (smatrix[ptr->sid[i]][j][k][4])
                                            {
                                                k=(int) smatrix[ptr->sid[i]][j][k][4];
                                            }
                                            else
                                            {
                                                break;
                                            }

                                        }
                                    }
                                    t=t->nxt_pos;
                                }

                            }

                            break;
                        }

                    }

                }


                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    if (bu[j])
                    {
                        for (int sic=0; sic<ptr->num_sitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==tslist[sic].seq)
                            {
                                tslist[sic].sid[tslist[sic].num_seqs]=ptr->sid[i];
                                tslist[sic].iid[tslist[sic].num_seqs]=j;
                                tslist[sic].pivot[tslist[sic].num_seqs]=sortpivot(bu[j]);
                                tslist[sic].num_seqs++;
                                break;
                            }
                        }
                    }
                }
                delete [] bu;
            }

            /*
            for (int i=0; i<ptr->num_sitems; i++)
            {
            if (slist[i].nodeutility>=utility_threashold)
            husp.insert(element(ptr->prefix+"]["+to_string(slist[i].seq)+"]",slist[i].nodeutility));
            }
            */
            for (int i=0; i<ptr->num_sitems; i++)
            {
                slist[i].prefix=ptr->prefix+"]["+to_string(slist[i].seq)+"+";
                //cout<<slist[i].seq<<" #seqs: "<<slist[i].num_seqs<<" "<<slist[i].swu<<" "<<slist[i].maxutility<<" "<<slist[i].nodeutility<<endl;
                HUSdfs(&(slist[i]), 1);
            }
            /*if (ptr->prefix=="[1+")
            {
                cout<<ptr->pivot[0]->num_fitem_in_Q[0];
                char ch;
                cin>>ch;
            }*/
        }

        if (tslist)
        {
            delete [] tslist;
            tslist=0;
        }

        tree_node *eilist=0;
        int ieitems=0;

        if (num_ieitems>0)
        {

            eilist=new tree_node[num_ieitems];
            for (int i=0; i<num_ieitems; i++)
            {
                if (teilist[i].swu>=utility_threashold)
                {
                    eilist[ieitems]=teilist[i];
                    //cout<<ptr->seq+"]["+eilist[sitems].seq<<endl;
                    ieitems++;
                }
            }
            if (ieitems==0)
            {
                delete [] eilist;
                eilist=0;
            }
            num_ieitems=ieitems;
        }
        delete [] teilist;
        teilist=0;

        if (num_ieitems>0)
        {
            for (int i=0; i<num_ieitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<num_ieitems; j++)
                {
                    if (eilist[j].seq<eilist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=eilist[i];
                    eilist[i]=eilist[imin];
                    eilist[imin]=temp;
                }
            }
            for (int i=0; i<num_ieitems; i++)
            {
                //cout<<ptr->seq+"]["+eilist[i].seq<<" "<<eilist[i].swu<<endl;
                eilist[i].num_items=ptr->num_items;
                eilist[i].pivot=new position *[eilist[i].num_seqs] {0};
                eilist[i].sid=new int[eilist[i].num_seqs] {0};
                eilist[i].iid=new int[eilist[i].num_seqs] {0};
                eilist[i].u_in_s=new double [eilist[i].num_seqs] {0};
                eilist[i].num_seqs=0;
            }

            teilist=eilist;
        }

        tree_node *eslist=0;
        int seitems=0;
        if (num_seitems>0)
        {
            eslist=new tree_node[num_seitems];
            for (int i=0; i<num_seitems; i++)
            {
                if (teslist[i].swu>=utility_threashold)
                {
                    eslist[seitems]=teslist[i];
                    //cout<<ptr->seq+"]["+eslist[sitems].seq<<endl;
                    seitems++;
                }
            }
            if (seitems==0)
            {
                delete [] eslist;
                eslist=0;
            }
            num_seitems=seitems;
        }
        delete [] teslist;
        teslist=0;

        if (num_seitems>0)
        {
            for (int i=0; i<num_seitems-1; i++)
            {
                int imin=i;
                for (int j=i+1; j<num_seitems; j++)
                {
                    if (eslist[j].seq<eslist[imin].seq)
                    {
                        imin=j;
                    }
                }
                if (imin!=i)
                {
                    tree_node temp=eslist[i];
                    eslist[i]=eslist[imin];
                    eslist[imin]=temp;
                }
            }

            for (int i=0; i<num_seitems; i++)
            {
                //cout<<ptr->seq+"]["+eslist[i].seq<<" "<<eslist[i].swu<<endl;
                /*if ((!eslist[i].num_seqs))
                {
                    cout<<eslist[i].seq<<"-....................."<<endl;
                }*/
                eslist[i].num_items=ptr->num_items;
                eslist[i].pivot=new position *[eslist[i].num_seqs] {0};
                eslist[i].sid=new int[eslist[i].num_seqs] {0};
                eslist[i].iid=new int[eslist[i].num_seqs] {0};
                eslist[i].u_in_s=new double [eslist[i].num_seqs] {0};
                eslist[i].num_seqs=0;
            }
            teslist=eslist;
        }

        if (num_seitems || num_ieitems)
        {
            for (int i=0; i<ptr->num_seqs; i++)
            {
                position **buei=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                position **bues=new position *[num_items_in_sequence[ptr->sid[i]]] {0};
                position *t=ptr->pivot[i];
                while (t)
                {
                    for (int is=0; is<t->num_oatp; is++)
                    {
                        if (t->num_fitem_in_Q[is])
                        {
                            if (t->forderQ[is][1]==t->p)
                            {
                                for (int sic=0; sic<num_ieitems; sic++)
                                {
                                    if (items_in_sequence[ptr->sid[i]][t->fitemQ[is][1]]==teilist[sic].seq)
                                    {
                                        int j=t->fitemQ[is][1];
                                        if (!buei[j])
                                        {
                                            buei[j]=new position;
                                            int *iq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            int *oq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                            copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                            int tp=t->forderQ[is][1];
                                            pop_node_from_Q(iq,oq,t->num_fitem_in_Q[is]);

                                            //int n=insert_node_into_Q(items_in_sequence[ptr->sid[i]][j],(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                            buei[j]->insert_mouatp(tp,t->mouatp[is],iq,oq,t->num_fitem_in_Q[is]-1);
                                            if (t->mouatp[is]>=teilist[sic].u_in_s[teilist[sic].num_seqs])
                                            {
                                                teilist[sic].u_in_s[teilist[sic].num_seqs]=t->mouatp[is];
                                            }

                                        }
                                        else
                                        {
                                            position *temp=buei[j];
                                            bool found=false;
                                            if (temp->p==t->forderQ[is][1])
                                            {
                                                found=true;
                                            }
                                            if (!found)
                                            {
                                                while (temp->nxt_pos)
                                                {
                                                    if (temp->nxt_pos->p==t->forderQ[is][1])
                                                    {
                                                        found=true;
                                                        break;
                                                    }
                                                    temp=temp->nxt_pos;
                                                }
                                                if (!found)
                                                {
                                                    temp->nxt_pos=new position;
                                                }
                                                temp=temp->nxt_pos;
                                            }
                                            int *iq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            int *oq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                            copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                            int tp=t->forderQ[is][1];
                                            pop_node_from_Q(iq,oq,t->num_fitem_in_Q[is]);

                                            //int n=insert_node_into_Q(items_in_sequence[ptr->sid[i]][j],(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                            temp->insert_mouatp(tp,t->mouatp[is],iq,oq,t->num_fitem_in_Q[is]-1);
                                            if (t->mouatp[is]>teilist[sic].u_in_s[teilist[sic].num_seqs])
                                            {
                                                teilist[sic].u_in_s[teilist[sic].num_seqs]=t->mouatp[is];
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            else if (t->forderQ[is][1]>t->p)
                            {
                                for (int sic=0; sic<num_seitems; sic++)
                                {
                                    if (items_in_sequence[ptr->sid[i]][t->fitemQ[is][1]]==teslist[sic].seq)
                                    {
                                        int j=t->fitemQ[is][1];
                                        if (!bues[j])
                                        {
                                            bues[j]=new position;
                                            int *iq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            int *oq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                            copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                            int tp=t->forderQ[is][1];
                                            pop_node_from_Q(iq,oq,t->num_fitem_in_Q[is]);

                                            //int n=insert_node_into_Q(items_in_sequence[ptr->sid[i]][j],(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                            bues[j]->insert_mouatp(tp,t->mouatp[is],iq,oq,t->num_fitem_in_Q[is]-1);
                                            if (t->mouatp[is]>=teslist[sic].u_in_s[teslist[sic].num_seqs])
                                            {
                                                teslist[sic].u_in_s[teslist[sic].num_seqs]=t->mouatp[is];
                                            }

                                        }
                                        else
                                        {
                                            position *temp=bues[j];
                                            bool found=false;
                                            if (temp->p==t->forderQ[is][1])
                                            {
                                                found=true;
                                            }
                                            if (!found)
                                            {
                                                while (temp->nxt_pos)
                                                {
                                                    if (temp->nxt_pos->p==t->forderQ[is][1])
                                                    {
                                                        found=true;
                                                        break;
                                                    }
                                                    temp=temp->nxt_pos;
                                                }
                                                if (!found)
                                                {
                                                    temp->nxt_pos=new position;
                                                }
                                                temp=temp->nxt_pos;
                                            }
                                            int *iq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            int *oq=new int [1+t->num_fitem_in_Q[is]] {0};
                                            copyQ(t->fitemQ[is],iq,t->num_fitem_in_Q[is]);
                                            copyQ(t->forderQ[is],oq,t->num_fitem_in_Q[is]);
                                            int tp=t->forderQ[is][1];
                                            pop_node_from_Q(iq,oq,t->num_fitem_in_Q[is]);

                                            //int n=insert_node_into_Q(items_in_sequence[ptr->sid[i]][j],(int) smatrix[ptr->sid[i]][j][k][2],iq,oq, t->num_fitem_in_Q[is]);
                                            temp->insert_mouatp(tp,t->mouatp[is],iq,oq,t->num_fitem_in_Q[is]-1);
                                            if (t->mouatp[is]>teslist[sic].u_in_s[teslist[sic].num_seqs])
                                            {
                                                teslist[sic].u_in_s[teslist[sic].num_seqs]=t->mouatp[is];
                                            }
                                        }

                                        break;
                                    }
                                }

                            }

                        }
                    }
                    t=t->nxt_pos;
                }
                for (int j=0; j<num_items_in_sequence[ptr->sid[i]]; j++)
                {
                    if (buei[j])
                    {
                        for (int sic=0; sic<num_ieitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==teilist[sic].seq)
                            {
                                teilist[sic].sid[teilist[sic].num_seqs]=ptr->sid[i];
                                teilist[sic].iid[teilist[sic].num_seqs]=j;
                                teilist[sic].pivot[teilist[sic].num_seqs]=sortpivot(buei[j]);
                                if (!(buei[j]->num_fitem_in_Q[0]))
                                {
                                    teilist[sic].nodeutility+=teilist[sic].u_in_s[teilist[sic].num_seqs];
                                }
                                teilist[sic].num_seqs++;
                                break;
                            }
                        }
                    }
                    if (bues[j])
                    {
                        for (int sic=0; sic<num_seitems; sic++)
                        {
                            if (items_in_sequence[ptr->sid[i]][j]==teslist[sic].seq)
                            {
                                teslist[sic].sid[teslist[sic].num_seqs]=ptr->sid[i];
                                teslist[sic].iid[teslist[sic].num_seqs]=j;
                                teslist[sic].pivot[teslist[sic].num_seqs]=sortpivot(bues[j]);
                                if (!(bues[j]->num_fitem_in_Q[0]))
                                {
                                    teslist[sic].nodeutility+=teslist[sic].u_in_s[teslist[sic].num_seqs];
                                }
                                teslist[sic].num_seqs++;
                                break;
                            }
                        }
                    }
                }
                delete [] buei;
                delete [] bues;
            }

            if (num_ieitems>0)
            {
                for (int i=0; i<num_ieitems; i++)
                {
                    eilist[i].prefix=ptr->prefix+","+to_string(eilist[i].seq)+"-";
                    if (eilist[i].nodeutility && eilist[i].nodeutility>=utility_threashold)
                        husp.insert(element(eilist[i].prefix+"]",eilist[i].nodeutility));
                }

                for (int i=0; i<num_ieitems; i++)
                {
                    //cout<<eilist[i].seq<<" #seqs: "<<eilist[i].num_seqs<<" "<<eilist[i].swu<<" "<<eilist[i].maxutility<<" "<<eilist[i].nodeutility<<endl;
                    HUSdfs(&(eilist[i]), 0);
                }
                /*if (ptr->prefix=="[1+")
                {
                    cout<<ptr->pivot[0]->num_fitem_in_Q[0];
                    char ch;
                    cin>>ch;
                }*/
            }

            if (num_seitems>0)
            {
                for (int i=0; i<num_seitems; i++)
                {
                    eslist[i].prefix=ptr->prefix+"]["+to_string(eslist[i].seq)+"-";
                    if (eslist[i].nodeutility && eslist[i].nodeutility>=utility_threashold)
                        husp.insert(element(eslist[i].prefix+"]",eslist[i].nodeutility));
                }

                for (int i=0; i<num_seitems; i++)
                {
                    //cout<<eslist[i].seq<<" #seqs: "<<eslist[i].num_seqs<<" "<<eslist[i].swu<<" "<<eslist[i].maxutility<<" "<<eslist[i].nodeutility<<endl;
                    HUSdfs(&(eslist[i]), 0);

                }
                /*if (ptr->prefix=="[1+")
                {
                    cout<<ptr->pivot[0]->num_fitem_in_Q[0];
                    char ch;
                    cin>>ch;
                }*/
            }

        }

        if (teilist)
        {
            delete [] teilist;
        }
        if (teslist)
        {
            delete [] teslist;
        }

        num_candidates+=ptr->num_iitems+ptr->num_sitems+num_ieitems+num_seitems;
    }



//    cout<<"wh...........\n";
    if (ptr->pivot)
    {
        int size_chain=0;
        /*
        for (int j=0; j<ptr->num_seqs; j++)
        {
            cout<< ptr->sid[j]<<" "<<ptr->iid[j]<<endl;
            //char ct;
            //cin>>ct;
            cout<<"........................"<<endl;
            int size_list=0;
            position *s=ptr->pivot[j];
            int counter=0;
            while(s)
            {

                position *temp=s;
                //cout<<s->p[0]<<" "<<s->p[1]<<" "<<s->p[2]<<" "<<s->utility<<endl;
                cout<<temp->p<<" "<<temp->last_p<<endl;
                cout<<"******************"<<endl;
                size_list++;
                s=s->nxt_pos;
                for (int is=0; is<temp->num_oatp; is++)
                {
                    cout<<temp->mouatp[is]<<endl;
                    for (int ni=1; ni<=temp->num_fitem_in_Q[is]; ni++)
                    {
                        cout<<temp->fitemQ[is][ni]<<" ";
                    }
                    cout<<endl;
                    for (int ni=1; ni<=temp->num_fitem_in_Q[is]; ni++)
                    {
                        cout<<temp->forderQ[is][ni]<<" ";
                    }
                    cout<<endl;
                    delete [] temp->fitemQ[is];
                    delete [] temp->forderQ[is];
                }
                delete [] temp->num_fitem_in_Q;
                delete [] temp->mouatp;
                delete [] temp->fitemQ;
                delete [] temp->forderQ;
                delete temp;
            }

        }
        delete [] ptr->iid;
        delete [] ptr->pivot;
        delete [] ptr->sid;
        delete [] ptr->u_in_s;
        */
        //cout<<"2499 "<<ptr->prefix<<" "<<ptr->num_seqs<<endl;
        for (int j=0; j<ptr->num_seqs; j++)
        {

            int size_list=0;
            //cout<<ptr->sid[j];
            position *s=ptr->pivot[j];
            while(s)
            {

                position *temp=s;
                size_list++;
                s=s->nxt_pos;

                for (int is=0; is<(temp->num_oatp); is++)
                {
                    /*cout<<temp->num_fitem_in_Q[is]<<" ";
                    for (int k=1; k<=temp->num_fitem_in_Q[is]; k++)
                    {
                        cout<<"("<<items_in_sequence[ptr->sid[j]][temp->fitemQ[is][k]]<<", "<<temp->forderQ[is][k]<<")";
                    }
                    cout<<" ";*/
                    delete [] temp->fitemQ[is];
                    delete [] temp->forderQ[is];
                }
                delete [] temp->num_fitem_in_Q;
                delete [] temp->mouatp;
                delete [] temp->fitemQ;
                delete [] temp->forderQ;
                delete temp;
            }
            size_chain+=size_list;
            if (size_list>max_num_element_in_ulist)
            {
                max_num_element_in_ulist=size_list;
            }
        }
        //cout<<"2715"<<endl;

        delete [] ptr->pivot;
        //cout<<ptr->num_seqs<<endl;

        if (size_chain>max_num_element_in_uchain)
        {
            max_num_element_in_uchain=size_chain;
        }
        num_elements_in_uchain+=size_chain;
        num_proj_sequences+=ptr->num_seqs;
        delete [] ptr->sid;
        delete [] ptr->u_in_s;
        //cout<<ptr->num_seqs<<endl;
        /*for (int j=0; j<ptr->num_seqs; j++)
        {
            cout<<"2546"<<ptr->iid[j]<<" "<<endl;
        }*/
        delete [] ptr->iid;
        //cout<<"2549"<<endl;
        //ptr->pivot=0;
        //delete [] ptr->maxuats;
    }


}

int main()
{
    clock_t start, finishtimeofloadumatrix,startrun, finish;
    double duration=0;
    start = clock();



    double mean=8;
    double stdev=8;
    string smean=to_string(mean);
    string sstdev=to_string(stdev);
    string meanstdpair="("+smean+","+sstdev+")";//""
    string f_utb=fname+"_utb"+meanstdpair;//D500C10T2.5N0.1+"_eu1""utb""utb"
    ifstream is((fpath+f_utb+".txt").c_str());
    //ofstream os("ok.data");
    if (is.fail())
        cout<<"fail"<<endl;
    string line;



    while (is>>itemset[num_items]>>utb[num_items])
    {
        //cout<<itemset[num_items]<<" "<<utb[num_items]<<endl;
        num_items++;
        if (num_items>=max_num_items)
        {
            max_num_items*=2;
            int *temp_itemset=new int [max_num_items];
            double *temp_utb=new double [max_num_items];
            for(int i=0; i<num_items; i++)
            {
                temp_itemset[i]=itemset[i];
                temp_utb[i]=utb[i];
            }
            delete [] itemset;
            delete [] utb;
            itemset=temp_itemset;
            utb=temp_utb;
        }

    }
    is.close();
    string f_usdb=fname+"_"+meanstdpair;//+"_testdb""sdb""sdb"
    ifstream is2((fpath+f_usdb+".txt").c_str());
    int max_num_seqs=100000;
    int num_seqs=0;

    event_seq *isid=new event_seq[max_num_seqs];
    int tsid=0;
    int tevent=0;
    double stime=0;
    double ftime=0;
    double tiu=0;
//    cout<<num_items<<"\n";
    while (is2>>tsid>>tevent>>stime>>ftime>>tiu)
    {
        if (stime<ftime)
        {
            //cout<<tsid<<" "<<tevent<<" "<<stime<<" "<<ftime<<" "<<tiu<<endl;
            bool hitseq=false;
            for (int i=num_seqs-1; i>=0; i--)
            {
                if (tsid==isid[i].isid)
                {
                    hitseq=true;
                    isid[i].insert_uei(tevent,stime,ftime,computeitemutility(tevent,tiu));
                    break;
                }
            }
            if (!hitseq)
            {
                if (num_seqs>=max_num_seqs)
                {
                    max_num_seqs*=2;
                    event_seq *tempsid=new event_seq[max_num_seqs];
                    for (int i=0; i<num_seqs; i++)
                    {
                        tempsid[i]=isid[i];
                    }
                    delete [] isid;
                    isid=tempsid;
                }
                isid[num_seqs].isid=tsid;
                isid[num_seqs].insert_uei(tevent,stime,ftime,computeitemutility(tevent,tiu));
                num_seqs++;
            }

        }
    }
    is2.close();
//    cout<<num_seqs<<"\n";
    delete [] itemset;
    delete [] utb;
    double dbutility=0;
    //double uthre=utility_threashold;
    num_itemsets_in_sequence=new int[num_seqs] {0};
    num_items_in_sequence=new int[num_seqs] {0};
    smatrix=new double ***[num_seqs] {0};
    items_in_sequence=new int *[num_seqs] {0};
    su=new double [num_seqs] {0};
    endru=new double *[num_seqs] {0};
    for (int i=0; i<num_seqs; i++)
    {
        sort_events_in_a_seq(isid,i);
        //cout<<isid[i].isid<<" ";
        for (int j=0; j<isid[i].num_e; j++)
        {
            if (isid[i].e[j].num_eiv>1)
            {
                //cout<<isid[i].isid<<" "<<isid[i].e[j].event<<" "<<isid[i].e[j].num_eiv<<endl;
                //cout<<"......................................."<<endl;
                for (int k=0; k<isid[i].e[j].num_eiv; k++)
                {
//                    cout<<isid[i].e[j].uei[k].stime<<" "<<isid[i].e[j].uei[k].ftime<<endl;
                }
                //cout<<"......................................."<<endl;
                for (int k=0; k<isid[i].e[j].num_eiv-1; k++)
                {
                    for (int l=k+1; l<isid[i].e[j].num_eiv; l++)
                    {
                        if (isid[i].e[j].uei[k].stime>isid[i].e[j].uei[l].ftime)
                        {

                        }
                        else if(isid[i].e[j].uei[k].ftime<isid[i].e[j].uei[l].stime)
                        {

                        }
                        else
                        {

                            if (isid[i].e[j].uei[k].stime==isid[i].e[j].uei[l].stime)
                            {
                                //cout<<isid[i].e[j].event<<" s ";

                                if (isid[i].e[j].uei[k].ftime==isid[i].e[j].uei[l].ftime)
                                {
                                    //cout<<isid[i].e[j].event<<" sf ";
                                }
                                else
                                {
                                    //cout<<isid[i].e[j].event<<" s ";
                                }
                            }
                            else
                            {
                                //if (isid[i].e[j].uei[k].ftime==isid[i].e[j].uei[l].ftime)
                                //cout<<isid[i].e[j].event<<" f ";
                                //if (isid[i].e[j].uei[k].ftime==isid[i].e[j].uei[l].stime)
                                //cout<<isid[i].e[j].event<<" f.s ";
                            }



                        }
                    }
                }
            }
        }
        //cout<<endl;
        dbutility+=su[i];

        //cout<<"<"<<line<<">: "<<su[num_seqs]<<endl;
        /*
        cout<<"..................."<<i<<"................"<<endl;
        for (int j=0; j<num_items_in_sequence[i]; j++)
        {
            cout<<items_in_sequence[i][j]<<" ";
            for (int k=0; k<num_itemsets_in_sequence[i]; k++)
            {
                cout<<"("<<smatrix[i][j][k][0]<<", "<<smatrix[i][j][k][1]<<", ";
                if (smatrix[i][j][k][0]) cout<<smatrix[i][j][k][2]+1<<", ";
                else cout<<smatrix[i][j][k][2]<<", ";
                if (smatrix[i][j][k][4]) cout<<smatrix[i][j][k][4]+1<<", ";
                else cout<<smatrix[i][j][k][4]<<", ";
                if (smatrix[i][j][k][3]) cout<<smatrix[i][j][k][3]+1;
                else cout<<smatrix[i][j][k][3];
                cout<<")";
            }
            cout<<endl;
            cout<<endl;
        }
        */



    }

    finishtimeofloadumatrix= clock();


    double tempthreshold=utility_threashold;
    for (int round=0; round<rounds; round++)
    {
        double uthre=increment*round;
        uthre=utility_threashold-uthre;
        tempthreshold=utility_threashold;
        utility_threashold=dbutility*uthre;
        string u_threshold=to_string(uthre);
        num_peu=1;
        num_elements_in_uchain=0;
        max_num_element_in_ulist=0;
        max_num_element_in_uchain=0;
        num_proj_sequences=0;
        startrun = clock();
        tree_node root;
        root.num_seqs=num_seqs;
        tree_node *childptr=new tree_node[num_items];
        root.num_items=num_items;
        if (!(husp.n))
        {
            husp.k=2;
            husp.HUSset=new element [husp.k+1];
        }
        //cout<<num_items<<" "<<num_seqs<<endl;


        for (int i=0; i<root.num_seqs; i++)
        {
            for (int j=0; j<num_items_in_sequence[i]; j++)
            {
                bool match_item=false;
                for (int kk=0; kk<root.num_sitems; kk++)
                {
                    if (items_in_sequence[i][j]==childptr[kk].seq)
                    {
                        childptr[kk].swu+=smatrix[i][j][0][1];
                        childptr[kk].num_seqs++;
                        match_item=true;
                        break;
                    }
                }
                if (!match_item)
                {
                    childptr[root.num_sitems].seq=items_in_sequence[i][j];
                    childptr[root.num_sitems].num_seqs++;
                    childptr[root.num_sitems].swu+=smatrix[i][j][0][1];
                    (root.num_sitems)++;
                }
            }
        }

        //bool update_db=false;
        //root.num_items=root.num_sitems;
        //cout<<root.num_sitems<<endl;
        tree_node *slist=new tree_node[root.num_sitems];
        int sitems=0;
        for (int i=0; i<root.num_sitems; i++)
        {
            //width pruning
            if (childptr[i].swu>=utility_threashold)
            {
                slist[sitems]=childptr[i];
                sitems++;
            }
        }
        if (!sitems)
        {
            delete [] slist;
            slist=0;
        }
        root.num_sitems=sitems;
        //cout<<root.num_sitems<<endl;
        //cout<<"here\n";
        delete [] childptr;
        childptr=0;

        for (int i=0; i<root.num_sitems-1; i++)
        {
            int imin=i;
            for (int j=i+1; j<root.num_sitems; j++)
            {
                if (slist[j].seq<slist[imin].seq)
                {
                    imin=j;
                }
            }
            if (imin!=i)
            {
                tree_node temp=slist[i];
                slist[i]=slist[imin];
                slist[imin]=temp;
            }
        }
        num_candidates=root.num_sitems;
        for (int i=0; i<root.num_sitems; i++)
        {
            slist[i].num_items=root.num_items;
            slist[i].pivot=new position *[slist[i].num_seqs] {0};
            slist[i].iid=new int[slist[i].num_seqs] {0};
            slist[i].sid=new int[slist[i].num_seqs] {0};
            slist[i].u_in_s=new double[slist[i].num_seqs] {0};
            //slist[i].ufQ=new double *[slist[i].num_seqs] {0};
            //slist[i].fitemQ=new int** [slist[i].num_seqs] {0};
            //slist[i].forderQ=new int** [slist[i].num_seqs] {0};
            //slist[i].num_fQ_in_seq=new int [slist[i].num_seqs] {0};
            //slist[i].max_num_fQ_in_seq=new int [slist[i].num_seqs] {0};
            //slist[i].num_fitem_in_Q_in_seq=new int *[slist[i].num_seqs] {0};
            //slist[i].max_num_fitem_in_Q_in_seq=new int *[slist[i].num_seqs] {0};
            slist[i].prefix="["+to_string(slist[i].seq)+"+";
            slist[i].num_seqs=0;
        }

        for (int i=0; i<root.num_seqs; i++)
        {
            for (int j=0; j<num_items_in_sequence[i]; j++)
            {
                int tempindex=0;
                bool match_item=false;
                for (int k=0; k<root.num_sitems; k++)
                {
                    if (slist[k].seq==items_in_sequence[i][j])
                    {
                        match_item=true;
                        tempindex=k;
                        //cout<<slist[tempindex].seq<<" "<<slist[tempindex].swu<<" "<<endl;
                        break;
                    }

                }
                if (match_item)
                {
                    //int counter=0;
                    //double tempu=0;
                    //bool projected=false;
                    position *temp=slist[tempindex].pivot[slist[tempindex].num_seqs];
                    //cout<<i<<" "<<j<<endl;
                    for (int k=0; smatrix[i][j][k][0]>0 || smatrix[i][j][k][4]>0; )
                    {
                        if (smatrix[i][j][k][0]>0)
                        {
                            //cout<<k<<endl;
                            //++counter;
                            //slist[tempindex].pivot[slist[tempindex].num_seqs]=new position(k,smatrix[i][j][k][0]);
                            //position *tt=slist[tempindex].pivot[slist[tempindex].num_seqs];
                            /*
                            if (tt->utility>tempu)
                                tempu=tt->utility;
                            for (int kk=k+1; kk<num_itemsets_in_sequence[i]; kk++)
                            {
                                if (smatrix[i][j][kk][0])
                                {
                                    ++counter;
                                    tt->nxt_pos=new position(kk,smatrix[i][j][kk][0]);
                                    if (tt->nxt_pos->utility>tempu)
                                        tempu=tt->nxt_pos->utility;
                                    tt=tt->nxt_pos;
                                }
                            }
                            */

                            if (!temp)
                            {
                                int *iq=new int [1+1] {0};
                                int *oq=new int [1+1] {0};
                                int n=insert_node_into_Q(j, (int) smatrix[i][j][k][2],
                                                         iq, oq, 0);
                                //cout<<n<<" "<<j<<" "<<(int) smatrix[i][j][k][2]<<endl;
                                /*for (int ioq=0; ioq<=n; ioq++)
                                {
                                    cout<<oq[ioq]<<endl;
                                }
                                */
                                slist[tempindex].pivot[slist[tempindex].num_seqs]=new position;
                                temp=slist[tempindex].pivot[slist[tempindex].num_seqs];
                                //cout<<"!wfffffffffffffffffffffffffffffffff\n";
                                temp->insert_mouatp(k,smatrix[i][j][k][0],iq,oq,n);
                                //cout<<"!wfffffffffffffffffffffffffffffffff\n";
                            }
                            else
                            {
                                int *iq=new int [1+1] {0};
                                int *oq=new int [1+1] {0};
                                int n=insert_node_into_Q(j, (int) smatrix[i][j][k][2],
                                                         iq, oq, 0);

                                temp->nxt_pos=new position;

                                temp=temp->nxt_pos;
                                temp->insert_mouatp(k,smatrix[i][j][k][0],iq,oq,n);
                                /*
                                if (slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]==slist[tempindex].max_num_fQ_in_seq[slist[tempindex].num_seqs])
                                {
                                    int mn=slist[tempindex].max_num_fQ_in_seq[slist[tempindex].num_seqs]*2;
                                    int **fiQ=new int* [mn] {0};
                                    int **foQ=new int* [mn] {0};
                                    double *uQ=new double [mn] {0};
                                    //slist[tempindex].fitemQ[slist[tempindex].num_seqs][slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]]
                                    //=new int
                                    int *max_n_fitem_in_Q=new int[mn] {0};
                                    int *n_fitem_in_Q=new int[mn] {0};
                                    for (int l=0; l<slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]; l++)
                                    {
                                        max_n_fitem_in_Q[l]=slist[tempindex].max_num_fitem_in_Q_in_seq[slist[tempindex].num_seqs][l];
                                        n_fitem_in_Q[l]=slist[tempindex].num_fitem_in_Q_in_seq[slist[tempindex].num_seqs][l];
                                        fiQ[l]=slist[tempindex].fitemQ[slist[tempindex].num_seqs][l];
                                        foQ[l]=slist[tempindex].forderQ[slist[tempindex].num_seqs][l];
                                        uQ[l]=slist[tempindex].ufQ[slist[tempindex].num_seqs][l];
                                    }
                                    delete [] slist[tempindex].max_num_fitem_in_Q_in_seq[slist[tempindex].num_seqs];
                                    delete [] slist[tempindex].num_fitem_in_Q_in_seq[slist[tempindex].num_seqs];
                                    delete [] slist[tempindex].fitemQ[slist[tempindex].num_seqs];
                                    delete [] slist[tempindex].forderQ[slist[tempindex].num_seqs];
                                    delete [] slist[tempindex].ufQ[slist[tempindex].num_seqs];
                                    slist[tempindex].max_num_fitem_in_Q_in_seq[slist[tempindex].num_seqs]=max_n_fitem_in_Q;
                                    slist[tempindex].num_fitem_in_Q_in_seq[slist[tempindex].num_seqs]=n_fitem_in_Q;
                                    slist[tempindex].fitemQ[slist[tempindex].num_seqs]=fiQ;
                                    slist[tempindex].forderQ[slist[tempindex].num_seqs]=foQ;
                                    slist[tempindex].ufQ[slist[tempindex].num_seqs]=uQ;
                                    slist[tempindex].max_num_fQ_in_seq[slist[tempindex].num_seqs]=mn;
                                    for (int l=slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]; l<slist[tempindex].max_num_fQ_in_seq[slist[tempindex].num_seqs]; l++)
                                    {
                                        slist[tempindex].max_num_fitem_in_Q_in_seq[slist[tempindex].num_seqs][l]=2;
                                    }
                                }
                                slist[tempindex].fitemQ[slist[tempindex].num_seqs]
                                [slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]]
                                    =new int [slist[tempindex].max_num_fitem_in_Q_in_seq[slist[tempindex].num_seqs]
                                              [slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]]
                                              +1
                                             ];
                                slist[tempindex].forderQ[slist[tempindex].num_seqs]
                                [slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]]
                                    =new int [slist[tempindex].max_num_fitem_in_Q_in_seq[slist[tempindex].num_seqs]
                                              [slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs]]
                                              +1
                                             ];
                                insert_node_into_Q(&(slist[tempindex]),
                                                   slist[tempindex].num_seqs,
                                                   slist[tempindex].num_fQ_in_seq[slist[tempindex].num_seqs],
                                                   items_in_sequence[i][j],
                                                   k,
                                                   smatrix[i][j][k][0]
                                                  );
                                */
                            }
                            if (smatrix[i][j][k][0]>slist[tempindex].u_in_s[slist[tempindex].num_seqs])
                            {
                                slist[tempindex].u_in_s[slist[tempindex].num_seqs]=smatrix[i][j][k][0];
                            }
                            if(!(smatrix[i][j][k][4]))
                            {
                                slist[tempindex].sid[slist[tempindex].num_seqs]=i;
                                slist[tempindex].iid[slist[tempindex].num_seqs]=j;
                                //slist[tempindex].nodeutility+=tempu;
                                slist[tempindex].num_seqs++;
                                break;
                            }
                            k=(int) smatrix[i][j][k][4];
                        }
                        else if (smatrix[i][j][k][4]>0)
                        {
                            k=(int) smatrix[i][j][k][4];
                        }
                        else
                        {
                            break;
                        }
                    }


                    /*
                    if (counter)
                    {
                        if (counter==1)
                        {
                            if (smatrix[i][j][slist[tempindex].pivot[slist[tempindex].num_seqs]->p][1])
                            {
                                slist[tempindex].maxuats[slist[tempindex].num_seqs]=slist[tempindex].pivot[slist[tempindex].num_seqs]->utility
                                        +smatrix[i][j][slist[tempindex].pivot[slist[tempindex].num_seqs]->p][1];
                                slist[tempindex].maxutility+=slist[tempindex].maxuats[slist[tempindex].num_seqs];
                                slist[tempindex].sid[slist[tempindex].num_seqs]=i;
                                slist[tempindex].iid[slist[tempindex].num_seqs]=j;
                                ++(slist[tempindex].num_seqs);
                            }
                            else
                            {
                                delete slist[tempindex].pivot[slist[tempindex].num_seqs];
                                slist[tempindex].pivot[slist[tempindex].num_seqs]=0;
                            }
                        }
                        else
                        {
                            slist[tempindex].maxuats[slist[tempindex].num_seqs]=slist[tempindex].pivot[slist[tempindex].num_seqs]->utility
                                    +smatrix[i][j][slist[tempindex].pivot[slist[tempindex].num_seqs]->p][1];
                            slist[tempindex].maxutility+=slist[tempindex].maxuats[slist[tempindex].num_seqs];
                            slist[tempindex].sid[slist[tempindex].num_seqs]=i;
                            slist[tempindex].iid[slist[tempindex].num_seqs]=j;
                            ++(slist[tempindex].num_seqs);
                        }

                    }
                    */

                }
            }
        }

        /*for (int i=0; i<root.num_sitems; i++)
        {
            for (int j=0; j<slist[i].num_seqs; j++)
            {
                position *t=slist[i].pivot[j];
                while (t)
                {
                    for (int k=0; k<t->num_oatp; k++)
                    {
                        if (t->num_fitem_in_Q[k]<=0)
                        {
                            cout<<slist[i].prefix<<" e04"<<endl;
                        }
                    }

                    t=t->nxt_pos;
                }
            }
        }*/
        for (int i=0; i<root.num_sitems; i++)
        {
            //cout<<slist[i].prefix<<endl;
            /*for (int j=0; j<slist[i].num_seqs; j++)
            {
                cout<<slist[i].sid[j]<<endl;
                position *t=slist[i].pivot[j];
                while(t)
                {
                    cout<<t->p<<" "<<t->last_p<<endl;
                    t=t->nxt_pos;
                }

            }*/
            /*
            if (slist[i].seq==4)
            {
                cout<<slist[i].num_seqs<<endl;
                tree_node *ptr=&(slist[i]);
                for (int j=0; j<ptr->num_seqs; j++)
                {
                    cout<<"sid: "<<ptr->sid[j]<<" iid: "<<ptr->iid[j]<<endl;
                    //char ct;
                    //cin>>ct;
                    cout<<"........................"<<endl;
                    position *s=ptr->pivot[j];
                    int counter=0;
                    while(s)
                    {

                        position *temp=s;
                        //cout<<s->p[0]<<" "<<s->p[1]<<" "<<s->p[2]<<" "<<s->utility<<endl;
                        cout<<"position: "<<temp->p<<" last_p: "<<temp->last_p<<endl;
                        cout<<"******************"<<endl;
                        s=s->nxt_pos;
                        for (int is=0; is<temp->num_oatp; is++)
                        {
                            cout<<temp->mouatp[is]<<endl;
                            for (int ni=1; ni<=temp->num_fitem_in_Q[is]; ni++)
                            {
                                cout<<temp->fitemQ[is][ni]<<" ";
                            }
                            cout<<endl;
                            for (int ni=1; ni<=temp->num_fitem_in_Q[is]; ni++)
                            {
                                cout<<temp->forderQ[is][ni]<<" ";
                            }
                            cout<<endl;

                        }
                        cout<<"******************"<<endl;
                    }

                }

            }
            */
            HUSdfs(&(slist[i]), true);
            //cout<<slist[i].prefix<<endl;

        }
        if (slist)
        {
            delete [] slist;
        }
        //return 0;
        finish = clock();
        duration=(double)(finishtimeofloadumatrix-start+finish-startrun)/CLOCKS_PER_SEC;
        GetProcessMemoryInfo( GetCurrentProcess(), &pmc, sizeof(pmc));
        double timeforloadsmatrix=(double)(finishtimeofloadumatrix-start)/CLOCKS_PER_SEC;
        double miningtime=(double)(finish-startrun)/CLOCKS_PER_SEC;
        //topk.print();
        //husp.print();
        cout<<"time: "<<duration<<"s."<<endl;
        cout<<"time of loading smatrix: "<<timeforloadsmatrix<<"s.\n";
        cout<<"mining time: "<<miningtime<<"s."<<endl;
        cout <<"memory usage: " << pmc.PeakWorkingSetSize<<" bytes"<< endl; //unit in bytes
        ofstream hus_performance((u_threshold+"_"+fname+meanstdpair+"_hus_mining_report 20150924.txt").c_str());
        hus_performance<<"performance of the Hus-Span algo.";
        hus_performance<<"time: "<<duration<<" s."<<endl;
        hus_performance<<"time of loading smatrix: "<<timeforloadsmatrix<<"s.\n";
        hus_performance<<"mining time: "<<miningtime<<"s."<<endl;
        hus_performance<<"#of expanded nodes: "<<num_peu<<endl;
        hus_performance<<"#of candidates: "<<num_candidates<<endl;
        hus_performance<<"#of elements in uchain: "<<num_elements_in_uchain<<endl;
        double avg_num_elements_per_candidate=(double)num_elements_in_uchain/num_candidates;
        hus_performance<<"avg #of elements per candidates: "<<avg_num_elements_per_candidate<<endl;
        hus_performance<<"max #of elements in a ulist: "<<max_num_element_in_ulist<<endl;
        hus_performance<<"max #of elements in uchain: "<<max_num_element_in_uchain<<endl;
        hus_performance<<"#of proj sequences: "<<num_proj_sequences<<endl;
        double avg_num_elements_per_seq=(double)num_elements_in_uchain/num_proj_sequences;
        hus_performance<<"avg #of elements per sequence: "<<avg_num_elements_per_seq<<endl;
        hus_performance <<"memory usage: " << pmc.PeakWorkingSetSize<<" bytes"<< endl;
        hus_performance<<"utility threashold: "<<utility_threashold<<endl;
        hus_performance<<"--------------------"<<husp.n<<" high utility sequences------------------"<<endl;
        for (int nhusp=1; nhusp<=husp.n; nhusp++)
        {
            hus_performance<<husp.HUSset[nhusp].seq<<" "<<husp.HUSset[nhusp].utility<<endl;
        }
        delete [] husp.HUSset;
        husp.HUSset=0;
        husp.n=0;
        husp.k=0;
        hus_performance.close();
        utility_threashold=tempthreshold;
    }

    for (int i=0; i<num_seqs; i++)
    {
        for (int j=0; j<num_items_in_sequence[i]; j++)
        {
            for (int k=0; k<num_itemsets_in_sequence[i]; k++)
                delete [] smatrix[i][j][k];
            delete [] smatrix[i][j];
        }
        delete [] smatrix[i];
    }

    delete [] smatrix;
    for (int i=0; i<num_seqs; i++)
    {
        delete [] items_in_sequence[i];
    }

    delete [] items_in_sequence;
    delete [] num_itemsets_in_sequence;
    delete [] num_items_in_sequence;
    delete [] su;
    su=0;
    return 0;
}
