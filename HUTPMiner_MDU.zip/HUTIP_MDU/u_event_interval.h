#ifndef U_EVENT_INTERVAL_H
#define U_EVENT_INTERVAL_H


class u_event_interval
{
public:
    u_event_interval();
    u_event_interval(double, double, double);
    virtual ~u_event_interval();
    double event_u;
    double stime;
    double ftime;
};

#endif // U_EVENT_INTERVAL_H
