#include "tree_node.h"
tree_node::tree_node()
{
    prefix="";
    seq=0;
    swu=0;
    maxutility=0;
    nodeutility=0;
    //concatenation=false;
    //length=0;
    //ufQ=0;
    //fitemQ=0;
    //forderQ=0;
    //num_fQ_in_seq=0;
    //max_num_fQ_in_seq=0;
    //num_fitem_in_Q_in_seq=0;
    //max_num_fitem_in_Q_in_seq=0;
    num_seqs=0;
    num_sitems=0;
    num_iitems=0;
    num_items=0;
    //num_items_in_sequence=0;
    //num_itemsets_in_sequence=0;
    //items_in_sequence=0;
    //itemset=0;
    u_in_s=0;
    pivot=0;
    sid=0;
    iid=0;
    //smatrix=0;
    //eq_item=teq_item;
}
/*
tree_node::tree_node(string s,double tu_upperbound,double tmaxu,double tnodeu, double ****tsmatrix, position** tp )
{
    //ctor
    seq=s;
    u_upperbound=tu_upperbound;
    pdu=tmaxu;
    nodeutility=tnodeu;
    pivot =tp;
    smatrix=tsmatrix;
    //eq_item=teq_item;

}
*/
/*
int tree_node::findindex(string item)
{
    int i=0;
    for (; i<num_items; i++)
    {
        if (item==itemset[i])
            return i;
    }
    return i;
}
*/
/*
void tree_node::setnodeutility(int num_seqs)
{
    for (int i=0;i<num_seqs;i++)
    {
        double tempu=0;
        position * t=pivot[i];
        while (t)
        {
            if ((t->utility)>tempu)
                tempu=t->utility;
            t=t->nxt_pos;
        }
        nodeutility+=tempu;
    }
}
void tree_node::setpdu(int num_seqs,double ****smatrix)
{
    for (int i=0;i<num_seqs;i++)
    {
        position * t=pivot[i];
        if (t)
        {
            pdu+=t->utility+smatrix[t->p[0]][t->p[1]][t->p][1];
        }
    }
}
*/
tree_node::~tree_node()
{
    //dtor
}
