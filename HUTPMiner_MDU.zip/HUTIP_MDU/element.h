#ifndef ELEMENT_H
#define ELEMENT_H
#include <string>
#include <iostream>
using namespace std;
class minheap;
class HUS;
class element
{
    friend class minheap;
    friend class HUS;
public:
    element();
    element(string, double);
    virtual ~element();
    string seq;
    double utility;
};

#endif // ELEMENT_H
