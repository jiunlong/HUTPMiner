#include "event_seq.h"

event_seq::event_seq()
{
    //ctor
    isid=0;
    e=0;
    num_e=0;
    max_num_e=2;
}
event_seq::event_seq(int tsid)
{
    //ctor
    isid=tsid;
    num_e=0;
    max_num_e=2;
    e=0;
}
void event_seq::merge_interval(int i)
{
    for (int j=0; j<e[i].num_eiv-1; j++)
    {
        int imin=j;
        for (int k=j+1; k<e[i].num_eiv; k++)
        {
            if (e[i].uei[k].stime<e[i].uei[imin].stime)
            {
                imin=k;
            }
            else if (e[i].uei[k].stime==e[i].uei[imin].stime)
            {
                if (e[i].uei[k].ftime<e[i].uei[imin].ftime)
                {
                    imin=k;
                }
            }
        }
        if (imin!=j)
        {
            u_event_interval temp=e[i].uei[imin];
            e[i].uei[imin]=e[i].uei[j];
            e[i].uei[j]=temp;
        }
    }
    for (int j=0; j<e[i].num_eiv-1; j++)
    {
        for (int k=j+1; k<e[i].num_eiv; k++)
        {
            if (e[i].uei[j].ftime<e[i].uei[k].stime)
            {
                break;
            }
            else
            {
                if (e[i].uei[k].ftime>e[i].uei[j].ftime)
                {
                    e[i].uei[j].ftime=e[i].uei[k].ftime;
                }
                e[i].uei[j].event_u+=e[i].uei[k].event_u;
                for (int l=k+1; l<e[i].num_eiv; l++)
                {
                    e[i].uei[l-1]=e[i].uei[l];
                }
                e[i].num_eiv--;
                merge_interval(i);
            }
        }
    }

}
void event_seq::insert_uei(int te, double st, double ft, double iu)
{
    bool hit_event=false;
    for (int i=0; i<num_e; i++)
    {
        if (e[i].event==te)
        {
            hit_event=true;
            bool is_mergerd=false;
            for (int j=0; j<e[i].num_eiv; j++)
            {
                if ((st>=e[i].uei[j].stime && st<=e[i].uei[j].ftime) || (ft>=e[i].uei[j].stime && ft<=e[i].uei[j].ftime))
                {
                    is_mergerd=true;
                    if (st<e[i].uei[j].stime)
                    {
                        e[i].uei[j].stime=st;
                    }
                    if (ft>e[i].uei[j].ftime)
                    {
                        e[i].uei[j].ftime=ft;
                    }
                    e[i].uei[j].event_u+=iu;
                    merge_interval(i);
                    break;
                }
            }
            if (!is_mergerd)
            {
                if (e[i].num_eiv==e[i].max_num_eiv)
                {
                    e[i].max_num_eiv*=2;
                    u_event_interval *tempuei=new u_event_interval[e[i].max_num_eiv];
                    for (int j=0; j<e[i].num_eiv; j++)
                    {
                        tempuei[j]=e[i].uei[j];
                    }
                    delete [] e[i].uei;
                    e[i].uei=tempuei;
                }
                e[i].uei[e[i].num_eiv].stime=st;
                e[i].uei[e[i].num_eiv].ftime=ft;
                e[i].uei[e[i].num_eiv].event_u=iu;
                e[i].num_eiv++;
            }
            break;
        }
    }
    if (!hit_event)
    {
        if (!e)
        {
            e=new event_set[max_num_e];
        }
        if (num_e==max_num_e)
        {
            max_num_e*=2;
            event_set *eset=new event_set[max_num_e];
            for (int i=0; i<num_e; i++)
            {
                eset[i]=e[i];
            }
            delete [] e;
            e=eset;
        }
        e[num_e].event=te;
        if (!e[num_e].uei)
        {
            e[num_e].uei=new u_event_interval[e[num_e].max_num_eiv];
        }
        e[num_e].uei[e[num_e].num_eiv].stime=st;
        e[num_e].uei[e[num_e].num_eiv].ftime=ft;
        e[num_e].uei[e[num_e].num_eiv].event_u=iu;
        e[num_e].num_eiv++;
        num_e++;
    }
}
event_seq::~event_seq()
{
    //dtor
}
