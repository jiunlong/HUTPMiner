#ifndef EVENT_SET_H
#define EVENT_SET_H
#include "u_event_interval.h"

class event_set
{
public:
    event_set();
    event_set(int);
    virtual ~event_set();
    int event;
    u_event_interval *uei;
    int num_eiv;
    int max_num_eiv;


};

#endif // EVENT_SET_H
