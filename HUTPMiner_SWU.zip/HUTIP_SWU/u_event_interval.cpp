#include "u_event_interval.h"

u_event_interval::u_event_interval()
{
    //ctor
    event_u=0;
    stime=0;
    ftime=0;
}
u_event_interval::u_event_interval(double u, double st, double ft)
{
    //ctor
    event_u=u;
    stime=st;
    ftime=ft;
}
u_event_interval::~u_event_interval()
{
    //dtor
}
