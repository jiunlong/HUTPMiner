#include <iostream>
#include "position.h"
using namespace std;
position::position()
{
    p=0;
    last_p=0;
    //p[0]=p[1]=p[2]=0;
    utility=0;
    nxt_pos=0;
    mouatp=0;
    num_oatp=0;
    max_num_oatp=2;
    fitemQ=0;
    forderQ=0;
    num_fitem_in_Q=0;
    //max_num_fitem_in_Q=2;
    //ctor
}
position::position(int k)
{
    p=k;
    last_p=0;
    utility=0;
    nxt_pos=0;
    mouatp=0;
    num_oatp=0;
    max_num_oatp=2;
    fitemQ=0;
    forderQ=0;
    num_fitem_in_Q=0;
    //max_num_fitem_in_Q=2;

}
void position::insert_mouatp(int k, double u, int *iQ, int *orderQ, int sizeofQ)
{

    p=k;
    if (!mouatp)
    {
        mouatp=new double[max_num_oatp] {0};
        fitemQ=new int* [max_num_oatp] {0};
        forderQ=new int* [max_num_oatp] {0};
        num_fitem_in_Q=new int [max_num_oatp] {0};
    }
    if (num_oatp>=max_num_oatp)
    {
        max_num_oatp*=2;
        double *temp_mouatp=new double [max_num_oatp] {0};
        int **temp_iQ=new int* [max_num_oatp] {0};
        int **temp_orderQ=new int* [max_num_oatp] {0};
        int *temp_num_fitem_in_Q=new int [max_num_oatp] {0};
        for (int i=0; i<num_oatp; i++)
        {
            temp_mouatp[i]=mouatp[i];
            temp_iQ[i]=fitemQ[i];
            temp_orderQ[i]=forderQ[i];
            temp_num_fitem_in_Q[i]=num_fitem_in_Q[i];
        }
        delete [] mouatp;
        delete [] fitemQ;
        delete [] forderQ;
        delete [] num_fitem_in_Q;
        mouatp=temp_mouatp;
        fitemQ=temp_iQ;
        forderQ=temp_orderQ;
        num_fitem_in_Q=temp_num_fitem_in_Q;
    }
    if (!sizeofQ)
    {
        if (!num_oatp)
        {
            mouatp[num_oatp]=u;
            fitemQ[num_oatp]=iQ;
            forderQ[num_oatp]=orderQ;
            num_fitem_in_Q[num_oatp]=sizeofQ;
            num_oatp++;
        }
        else
        {
            if (u>mouatp[num_oatp-1])
            {
                mouatp[num_oatp-1]=u;
            }
            delete [] iQ;
            delete [] orderQ;
        }
    }
    else
    {
        mouatp[num_oatp]=u;
        fitemQ[num_oatp]=iQ;
        forderQ[num_oatp]=orderQ;
        num_fitem_in_Q[num_oatp]=sizeofQ;
        if (forderQ[num_oatp][1]>last_p)
        {
            last_p=forderQ[num_oatp][1];
        }
        num_oatp++;
    }

    //cout<<"!wfffffffffffffffffffffffffffffffff\n";

}
position::~position()
{
    //dtor
}
