#include "HUS.h"

HUS::HUS()
{
    //ctor
    HUSset=0;
    n=0;
    k=0;
}
HUS::HUS(int nk)
{
    //ctor
    n=0;
    k=nk;
    HUSset=new element [k+1];
}
void HUS::insert(element seq)
{

    n++;
    if (n<0)
    {
        cout<<"over the limit"<<endl;
        return;
    }

    if (n>k)
    {
        int maxsize=k*2;
        if (k*2<0 || k*2>=INT_MAX)
        {
            maxsize=INT_MAX-1;
        }
        element* tempq=new element[maxsize+1];
        for (int i=1; i<=k; i++)
        {
            tempq[i]=HUSset[i];
        }
        if (k*2<0 || k*2>=INT_MAX)
        {
            k=INT_MAX-1;
        }
        else
        {
            k*=2;
        }
        delete [] HUSset;
        HUSset=tempq;
    }
    HUSset[n]=seq;




}
void HUS::print ()
{
    cout<<"--------------------"<<n<<" high utility sequences------------------"<<endl;
    for (int i=1; i<=n; i++)
    {
        cout<<HUSset[i].seq<<" "<<HUSset[i].utility<<endl;
    }
}
HUS::~HUS()
{
    //dtor
    //delete [] HUSset;
}
