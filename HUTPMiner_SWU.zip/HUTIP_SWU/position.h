#ifndef POSITION_H
#define POSITION_H

//class tree_node;
//class ending_qitem;
class position
{
    //friend class tree_node;
    //friend class ending_qitem;
    public:
        position();
        position(int);
        virtual ~position();
        int p;
        int last_p;
        double utility;
        double *mouatp;
        int **fitemQ;
        int **forderQ;
        int *num_fitem_in_Q;
        //int *max_num_fitem_in_Q;
        int num_oatp;
        int max_num_oatp;
        position *nxt_pos;
        void insert_mouatp(int, double, int *, int *, int);
};

#endif // POSITION_H
