#ifndef EVENT_SEQ_H
#define EVENT_SEQ_H
#include "event_set.h"

class event_seq
{
public:
    event_seq();
    event_seq(int);
    int isid;
    event_set *e;
    int num_e;
    int max_num_e;
    void insert_uei(int, double, double, double);
    void merge_interval(int);
    virtual ~event_seq();

};

#endif // EVENT_SEQ_H
