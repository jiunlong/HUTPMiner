#ifndef HUS_H
#define HUS_H
#include <iostream>
#include <climits>
#include "element.h"
using namespace std;
class element;
class HUS
{
public:
    HUS();
    HUS(int);
    void insert(element );
    void print ();
    virtual ~HUS();
    element * HUSset;
    int n;
    int k;

};

#endif // HUS_H
